use std::io::{self, BufReader, Read};

use text_diff::{
    diff, diff_reader, side_by_side, similarity, unified_diff, word_diff, Change, WordChange,
};

// ---------------------------------------------------------------------------
// diff() — line splitting and Change construction
// ---------------------------------------------------------------------------

#[test]
fn diff_empty_inputs_yield_no_changes() {
    assert!(diff("", "").is_empty());
}

#[test]
fn diff_empty_string_has_zero_lines() {
    let r = diff("", "only");
    let inserts = r
        .iter()
        .filter(|c| matches!(c, Change::Insert { .. }))
        .count();
    let others = r.len() - inserts;
    assert_eq!(inserts, 1);
    assert_eq!(others, 0);
}

#[test]
fn diff_trailing_newline_does_not_produce_extra_line() {
    assert_eq!(diff("a\n", "a\n").len(), diff("a", "a").len());
    assert_eq!(diff("a\nb\n", "a\nb\n").len(), 2);
}

#[test]
fn diff_lines_are_split_on_newline() {
    let r = diff("alpha\nbeta\ngamma", "alpha\nbeta\ngamma");
    assert_eq!(r.len(), 3);
}

#[test]
fn diff_change_content_excludes_line_terminator() {
    let r = diff("alpha\nbeta\n", "alpha\nbeta\n");
    for c in &r {
        match c {
            Change::Equal { content, .. }
            | Change::Delete { content, .. }
            | Change::Insert { content, .. } => assert!(!content.contains('\n')),
        }
    }
}

// ---------------------------------------------------------------------------
// diff() — 1-based line numbering on every variant
// ---------------------------------------------------------------------------

#[test]
fn diff_equal_carries_one_based_line_numbers() {
    let r = diff("alpha\nbeta\ngamma", "alpha\nbeta\ngamma");
    if let Change::Equal {
        old_line, new_line, ..
    } = &r[0]
    {
        assert_eq!(*old_line, 1);
        assert_eq!(*new_line, 1);
    } else {
        panic!("expected first entry to be Equal");
    }
    if let Change::Equal {
        old_line, new_line, ..
    } = &r[2]
    {
        assert_eq!(*old_line, 3);
        assert_eq!(*new_line, 3);
    } else {
        panic!("expected third entry to be Equal");
    }
}

#[test]
fn diff_delete_carries_old_line_number_only() {
    let r = diff("alpha\nbeta\ngamma", "alpha\ngamma");
    let del = r
        .iter()
        .find_map(|c| match c {
            Change::Delete { old_line, content } => Some((*old_line, content.clone())),
            _ => None,
        })
        .expect("expected a Delete change");
    assert_eq!(del.0, 2);
    assert_eq!(del.1, "beta");
}

#[test]
fn diff_insert_carries_new_line_number_only() {
    let r = diff("alpha\ngamma", "alpha\nbeta\ngamma");
    let ins = r
        .iter()
        .find_map(|c| match c {
            Change::Insert { new_line, content } => Some((*new_line, content.clone())),
            _ => None,
        })
        .expect("expected an Insert change");
    assert_eq!(ins.0, 2);
    assert_eq!(ins.1, "beta");
}

// ---------------------------------------------------------------------------
// diff() — minimality of the edit script
// ---------------------------------------------------------------------------

fn edit_count(changes: &[Change]) -> usize {
    changes
        .iter()
        .filter(|c| !matches!(c, Change::Equal { .. }))
        .count()
}

#[test]
fn diff_minimal_single_line_replacement_is_two_ops() {
    let r = diff("alpha\nbeta\ngamma", "alpha\nXX\ngamma");
    assert_eq!(edit_count(&r), 2);
}

#[test]
fn diff_minimal_disjoint_inputs_count_all_lines() {
    let r = diff("a\nb\nc", "x\ny\nz");
    assert_eq!(edit_count(&r), 6);
}

#[test]
fn diff_minimal_subset_only_deletes_extras() {
    let r = diff("a\nb\nc\nd\ne", "a\nc\ne");
    assert_eq!(edit_count(&r), 2);
}

#[test]
fn diff_identical_inputs_have_no_edits() {
    let r = diff("alpha\nbeta\ngamma\n", "alpha\nbeta\ngamma\n");
    assert_eq!(edit_count(&r), 0);
    assert_eq!(r.len(), 3);
}

// ---------------------------------------------------------------------------
// diff() — natural reading order
// ---------------------------------------------------------------------------

#[test]
fn diff_changes_appear_in_natural_reading_order() {
    let r = diff("a\nb\nc\nd", "a\nB\nc\nD");
    // First and third entries are unchanged "a" and "c".
    if let Change::Equal { content, .. } = &r[0] {
        assert_eq!(content, "a");
    } else {
        panic!("expected Equal('a') first");
    }
    // Find the Equal("c") and assert it precedes any "D"-related Insert.
    let c_pos = r
        .iter()
        .position(|c| matches!(c, Change::Equal { content, .. } if content == "c"))
        .expect("expected Equal('c')");
    let d_pos = r
        .iter()
        .position(|c| matches!(c, Change::Insert { content, .. } if content == "D"))
        .expect("expected Insert('D')");
    assert!(c_pos < d_pos);
}

// ---------------------------------------------------------------------------
// unified_diff()
// ---------------------------------------------------------------------------

#[test]
fn unified_diff_identical_inputs_returns_empty_string() {
    assert_eq!(unified_diff("alpha\nbeta\n", "alpha\nbeta\n", 3), "");
    assert_eq!(unified_diff("", "", 0), "");
}

#[test]
fn unified_diff_uses_at_at_hunk_header_format() {
    let out = unified_diff("alpha\nbeta\ngamma\n", "alpha\nXX\ngamma\n", 1);
    assert!(out.starts_with("@@ -1,3 +1,3 @@\n"));
}

#[test]
fn unified_diff_context_lines_use_space_prefix() {
    let out = unified_diff("alpha\nbeta\ngamma\n", "alpha\nXX\ngamma\n", 1);
    assert!(out.contains(" alpha\n"));
    assert!(out.contains(" gamma\n"));
}

#[test]
fn unified_diff_deleted_lines_use_minus_prefix() {
    let out = unified_diff("alpha\nbeta\ngamma\n", "alpha\nXX\ngamma\n", 1);
    assert!(out.contains("-beta\n"));
}

#[test]
fn unified_diff_inserted_lines_use_plus_prefix() {
    let out = unified_diff("alpha\nbeta\ngamma\n", "alpha\nXX\ngamma\n", 1);
    assert!(out.contains("+XX\n"));
}

#[test]
fn unified_diff_every_rendered_line_ends_with_newline() {
    let out = unified_diff("alpha\nbeta\ngamma\n", "alpha\nXX\ngamma\n", 1);
    assert!(!out.is_empty());
    // Every individual line (hunk header and content lines alike) must end
    // with '\n'. Split on '\n', drop the trailing empty token that results
    // from the final newline, then verify no line was left without one.
    let newline_count = out.matches('\n').count();
    let line_count = out.split('\n').filter(|l| !l.is_empty()).count();
    assert_eq!(newline_count, line_count, "every rendered line must end with \\n");
}

#[test]
fn unified_diff_zero_length_at_first_line_uses_zero() {
    // Insert before the very first old line: old contributes 0 lines from the start
    let out = unified_diff("alpha\nbeta\n", "NEW\nalpha\nbeta\n", 0);
    assert!(out.contains("@@ -0,0 +1,1 @@"));
}

#[test]
fn unified_diff_zero_length_after_uses_previous_old_line_number() {
    // Insert after every old line: old contributes 0 lines, prev old line is 2
    let out = unified_diff("alpha\nbeta\n", "alpha\nbeta\nNEW\n", 0);
    assert!(out.contains("@@ -2,0 +3,1 @@"));
}

#[test]
fn unified_diff_zero_length_new_side_at_first_line_uses_zero() {
    // Pure deletion of the first line: new side has 0 lines from line 1
    let out = unified_diff("alpha\nbeta\n", "beta\n", 0);
    assert!(out.contains("@@ -1,1 +0,0 @@"));
}

#[test]
fn unified_diff_zero_length_new_side_after_uses_previous_new_line_number() {
    // Pure deletion at end: new side has 0 lines, prev new line is 1
    let out = unified_diff("alpha\nbeta\n", "alpha\n", 0);
    assert!(out.contains("@@ -2,1 +1,0 @@"));
}

fn count_hunks(unified: &str) -> usize {
    unified.lines().filter(|l| l.starts_with("@@ ")).count()
}

#[test]
fn unified_diff_merges_adjacent_changes_when_no_gap_remains() {
    // Changes at line 1 and line 7 of a 7-line file. With context = 3, both
    // context windows overlap (zero unchanged lines of gap remain), so the
    // prompt's MUST-merge rule applies and the output must be a single hunk.
    let old = "a\nb\nc\nd\ne\nf\ng\n";
    let new = "X\nb\nc\nd\ne\nf\nY\n";
    let out = unified_diff(old, new, 3);
    assert_eq!(count_hunks(&out), 1);
}

#[test]
fn unified_diff_produces_two_separate_hunks_when_gap_is_wide_enough() {
    // Changes at line 1 and line 10 of a 10-line file with context = 1.
    // The gap between them is 8 unchanged lines (lines 2–9), which is
    // strictly more than 2*context+1 = 3, so the context windows must NOT
    // merge and the output must contain exactly two @@ headers.
    let old = "A\nb\nc\nd\ne\nf\ng\nh\ni\nJ\n";
    let new = "X\nb\nc\nd\ne\nf\ng\nh\ni\nY\n";
    let out = unified_diff(old, new, 1);
    assert_eq!(count_hunks(&out), 2);
    // First hunk covers old line 1 (deletion) and its context; second covers
    // old line 10 (deletion) and its context — both headers must be present.
    assert!(out.contains("-A\n"));
    assert!(out.contains("+X\n"));
    assert!(out.contains("-J\n"));
    assert!(out.contains("+Y\n"));
}

// ---------------------------------------------------------------------------
// side_by_side()
// ---------------------------------------------------------------------------

fn first_line(s: &str) -> &str {
    s.lines().next().expect("expected at least one row")
}

#[test]
fn side_by_side_unchanged_row_uses_space_marker() {
    let out = side_by_side("alpha\n", "alpha\n", 5);
    let line = first_line(&out);
    // Format: <left><sp>|<sp><marker><sp>|<sp><right>
    // Marker is at position width + 3 (left col + " | ")
    let marker = line.chars().nth(5 + 3).expect("marker char");
    assert_eq!(marker, ' ');
}

#[test]
fn side_by_side_replacement_row_pairs_consecutive_delete_then_insert() {
    // The prompt's contract is conditional: IF the script contains a
    // Delete immediately followed by an Insert, THEN side_by_side renders
    // them as a single row with a '|' marker. The LCS algorithm is free
    // to produce either D-then-I or I-then-D for a single-line change,
    // so we inspect the script first and then validate the corresponding
    // contract — instead of forcing a particular tie-breaking choice.
    let old = "alpha\n";
    let new = "beta\n";
    let script = diff(old, new);
    let has_delete_then_insert = script
        .windows(2)
        .any(|w| matches!(w[0], Change::Delete { .. }) && matches!(w[1], Change::Insert { .. }));
    let out = side_by_side(old, new, 5);
    let row_count = out.lines().count();
    if has_delete_then_insert {
        assert_eq!(row_count, 1, "consecutive D-then-I must collapse to one row");
        let line = first_line(&out);
        let marker = line.chars().nth(5 + 3).expect("marker char");
        assert_eq!(marker, '|');
    } else {
        // No D-then-I pair: the deletion and insertion render as two
        // separate rows with '<' and '>' markers respectively.
        assert_eq!(row_count, 2, "without a D-then-I pair, expect two rows");
        let markers: Vec<char> = out
            .lines()
            .filter_map(|l| l.chars().nth(5 + 3))
            .collect();
        assert!(markers.contains(&'<'));
        assert!(markers.contains(&'>'));
    }
}

#[test]
fn side_by_side_deletion_row_uses_left_angle_marker_with_empty_right() {
    // Old has an extra final line, no insertion to pair with -> deletion row
    let out = side_by_side("alpha\nextra\n", "alpha\n", 5);
    // Second row corresponds to the unmatched delete
    let row = out.lines().nth(1).expect("expected two rows");
    let marker = row.chars().nth(5 + 3).expect("marker char");
    assert_eq!(marker, '<');
    // Right column of a deletion row must be empty (only padding spaces)
    let right = &row[(5 + 3 + 1 + 3)..];
    assert!(right.chars().all(|c| c == ' '));
}

#[test]
fn side_by_side_insertion_row_uses_right_angle_marker_with_empty_left() {
    let out = side_by_side("alpha\n", "alpha\nextra\n", 5);
    let row = out.lines().nth(1).expect("expected two rows");
    let marker = row.chars().nth(5 + 3).expect("marker char");
    assert_eq!(marker, '>');
    // Left column must be empty
    let left: String = row.chars().take(5).collect();
    assert!(left.chars().all(|c| c == ' '));
}

#[test]
fn side_by_side_columns_are_padded_to_exact_char_width() {
    let out = side_by_side("a\n", "b\n", 5);
    let line = first_line(&out);
    // Total chars = width(5) + " | "(3) + marker(1) + " | "(3) + width(5) = 17
    assert_eq!(line.chars().count(), 5 + 3 + 1 + 3 + 5);
}

#[test]
fn side_by_side_truncates_content_longer_than_width() {
    let out = side_by_side("hello\n", "world\n", 3);
    // Every row must be exactly 3+3+1+3+3 = 13 chars wide regardless of
    // whether "hello"/"world" pair into a replacement row or render as
    // two separate <,> rows.
    for line in out.lines() {
        assert_eq!(line.chars().count(), 3 + 3 + 1 + 3 + 3);
    }
    // Left-aligned truncation keeps the prefix, so "hel" and "wor" appear
    // somewhere in the rendered output and the discarded suffixes do not.
    assert!(out.contains("hel"));
    assert!(out.contains("wor"));
    assert!(!out.contains("llo"));
    assert!(!out.contains("rld"));
}

#[test]
fn side_by_side_width_is_in_unicode_scalar_values_not_bytes() {
    // "café" is 4 chars but 5 bytes; with width 4 it should fit exactly without padding.
    let out = side_by_side("café\n", "café\n", 4);
    let line = first_line(&out);
    assert_eq!(line.chars().count(), 4 + 3 + 1 + 3 + 4);
}

#[test]
fn side_by_side_renders_full_script_including_unchanged_rows() {
    let out = side_by_side("alpha\nbeta\ngamma\n", "alpha\nbeta\ngamma\n", 5);
    assert_eq!(out.lines().count(), 3);
}

#[test]
fn side_by_side_every_row_terminated_with_newline() {
    let out = side_by_side("alpha\nbeta\n", "alpha\nbeta\n", 5);
    assert!(out.ends_with('\n'));
    assert_eq!(out.matches('\n').count(), 2);
}

// ---------------------------------------------------------------------------
// word_diff()
// ---------------------------------------------------------------------------

fn reconstruct_old(words: &[WordChange]) -> String {
    words
        .iter()
        .filter_map(|w| match w {
            WordChange::Equal(s) | WordChange::Delete(s) => Some(s.as_str()),
            WordChange::Insert(_) => None,
        })
        .collect()
}

fn reconstruct_new(words: &[WordChange]) -> String {
    words
        .iter()
        .filter_map(|w| match w {
            WordChange::Equal(s) | WordChange::Insert(s) => Some(s.as_str()),
            WordChange::Delete(_) => None,
        })
        .collect()
}

#[test]
fn word_diff_reconstructs_both_inputs_verbatim() {
    let r = word_diff("the quick brown fox", "the slow brown fox");
    assert_eq!(reconstruct_old(&r), "the quick brown fox");
    assert_eq!(reconstruct_new(&r), "the slow brown fox");
}

#[test]
fn word_diff_preserves_repeated_whitespace_runs() {
    let r = word_diff("a   b", "a   b");
    assert_eq!(reconstruct_old(&r), "a   b");
    assert_eq!(reconstruct_new(&r), "a   b");
}

#[test]
fn word_diff_treats_punctuation_inside_word_as_one_token() {
    // The prompt defines a word as "a maximal run of non-whitespace
    // characters", so "hello,world" — which contains no whitespace — is
    // exactly one token. For two identical such inputs the minimal edit
    // script is a single Equal token covering the entire input.
    let r = word_diff("hello,world", "hello,world");
    assert_eq!(r.len(), 1);
    assert!(matches!(&r[0], WordChange::Equal(s) if s == "hello,world"));
}

#[test]
fn word_diff_identical_lines_yield_only_equal_tokens() {
    let r = word_diff("foo bar baz", "foo bar baz");
    assert!(r.iter().all(|w| matches!(w, WordChange::Equal(_))));
    assert_eq!(reconstruct_old(&r), "foo bar baz");
}

#[test]
fn word_diff_empty_inputs_yield_no_tokens() {
    let r = word_diff("", "");
    assert!(r.is_empty());
}

#[test]
fn word_diff_is_minimal_for_a_single_word_replacement() {
    // tokens(old) = ["the", " ", "cat"], tokens(new) = ["the", " ", "dog"]
    // LCS = 2 ("the" and " "), minimum edit count = (3 + 3) - 2*2 = 2.
    let r = word_diff("the cat", "the dog");
    let edits = r
        .iter()
        .filter(|w| !matches!(w, WordChange::Equal(_)))
        .count();
    assert_eq!(edits, 2);
}

// ---------------------------------------------------------------------------
// trait derives required on Change and WordChange
// ---------------------------------------------------------------------------

#[test]
fn change_and_word_change_derive_required_traits() {
    fn requires_eq<T: Eq>(_: &T) {}
    fn requires_clone<T: Clone>(_: &T) {}
    fn requires_debug<T: std::fmt::Debug>(_: &T) {}

    let script = diff("alpha\nbeta\n", "alpha\ngamma\n");
    let cloned = script.clone();
    assert_eq!(script, cloned);
    requires_eq(&script);
    requires_clone(&script);
    requires_debug(&script);
    let _ = format!("{:?}", script);

    let words = word_diff("the cat", "the dog");
    let words_cloned = words.clone();
    assert_eq!(words, words_cloned);
    requires_eq(&words);
    requires_clone(&words);
    requires_debug(&words);
    let _ = format!("{:?}", words);
}

// ---------------------------------------------------------------------------
// similarity()
// ---------------------------------------------------------------------------

#[test]
fn similarity_identical_inputs_yield_one() {
    assert_eq!(similarity("alpha\nbeta\n", "alpha\nbeta\n"), 1.0);
}

#[test]
fn similarity_both_empty_inputs_yield_one() {
    assert_eq!(similarity("", ""), 1.0);
}

#[test]
fn similarity_one_empty_input_yields_zero() {
    assert_eq!(similarity("", "alpha\nbeta\n"), 0.0);
    assert_eq!(similarity("alpha\nbeta\n", ""), 0.0);
}

#[test]
fn similarity_partial_overlap_matches_ratio_formula() {
    // 3 lines vs 3 lines, longest common subsequence = 2 (alpha, gamma)
    // ratio = 2 * 2 / (3 + 3) = 2/3
    let s = similarity("alpha\nbeta\ngamma\n", "alpha\nXX\ngamma\n");
    assert!((s - (2.0 / 3.0)).abs() < 1e-12);
}

#[test]
fn similarity_disjoint_inputs_yield_zero() {
    assert_eq!(similarity("a\nb\nc\n", "x\ny\nz\n"), 0.0);
}

#[test]
fn similarity_always_in_unit_interval() {
    let cases: &[(&str, &str)] = &[
        ("", "x\n"),
        ("a\nb", "a\nb\nc"),
        ("foo bar", "foo bar"),
        ("a", "b"),
        ("alpha\nbeta\ngamma\n", "alpha\ngamma\n"),
    ];
    for (a, b) in cases {
        let s = similarity(a, b);
        assert!(s >= 0.0 && s <= 1.0, "similarity({:?}, {:?}) = {}", a, b, s);
    }
}

// ---------------------------------------------------------------------------
// diff_reader()
// ---------------------------------------------------------------------------

#[test]
fn diff_reader_returns_same_script_as_in_memory_diff() {
    let old = "alpha\nbeta\ngamma\n";
    let new = "alpha\nXX\ngamma\n";
    let mut o: &[u8] = old.as_bytes();
    let mut n: &[u8] = new.as_bytes();
    let from_reader = diff_reader(&mut o, &mut n).expect("reader diff should succeed");
    let from_memory = diff(old, new);
    assert_eq!(from_reader, from_memory);
}

#[test]
fn diff_reader_handles_empty_streams() {
    let mut o: &[u8] = b"";
    let mut n: &[u8] = b"";
    let r = diff_reader(&mut o, &mut n).expect("empty reader diff should succeed");
    assert!(r.is_empty());
}

#[test]
fn diff_reader_handles_inputs_without_trailing_newline() {
    let mut o: &[u8] = b"alpha\nbeta";
    let mut n: &[u8] = b"alpha\nbeta";
    let r = diff_reader(&mut o, &mut n).expect("reader diff should succeed");
    assert_eq!(r.len(), 2);
    assert!(r.iter().all(|c| matches!(c, Change::Equal { .. })));
}

#[test]
fn diff_reader_propagates_io_errors() {
    struct ExplodingReader;
    impl Read for ExplodingReader {
        fn read(&mut self, _buf: &mut [u8]) -> io::Result<usize> {
            Err(io::Error::new(io::ErrorKind::Other, "boom"))
        }
    }

    let mut bad = BufReader::new(ExplodingReader);
    let mut good: &[u8] = b"alpha\n";
    let result = diff_reader(&mut bad, &mut good);
    assert!(result.is_err());
}
