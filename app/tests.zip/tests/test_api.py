import os
import sqlite3
import subprocess
import time
import uuid
import requests


def _unique(prefix="u"):
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def _project_dir():
    env = os.environ.get("POLL_PROJECT_DIR")
    if env:
        return env
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _find_polls_table(conn):
    tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    for (name,) in tables:
        cols = [c[1] for c in conn.execute(f"PRAGMA table_info('{name}')").fetchall()]
        if "lastActivityAt" in cols and "id" in cols:
            return name
    return None


def test_database_uses_wal_mode(server_url):
    assert server_url is not None, "Server is not running"
    db_path = os.path.join(_project_dir(), "polls.db")
    assert os.path.exists(db_path), "polls.db not found in project root"
    conn = sqlite3.connect(db_path)
    try:
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
    finally:
        conn.close()
    assert mode.lower() == "wal"


def test_create_poll_returns_poll_id(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Design Review",
            "description": "Quarterly review",
            "passphrase": "admin1234",
            "timeSlots": [
                {"date": "2030-07-01", "startTime": "10:00"},
                {"date": "2030-07-02", "startTime": "11:00"},
            ],
        },
        timeout=5,
    )
    assert resp.status_code == 201
    body = resp.json()
    assert isinstance(body.get("pollId"), str) and len(body["pollId"]) > 0


def test_create_poll_missing_title_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "description": "no title",
            "passphrase": "admin1234",
            "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400
    assert isinstance(resp.json().get("error"), str)


def test_create_poll_title_too_long_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "x" * 201,
            "description": "",
            "passphrase": "admin1234",
            "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_short_passphrase_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Quick Sync",
            "description": "",
            "passphrase": "abc",
            "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_empty_time_slots_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "No Slots",
            "description": "",
            "passphrase": "admin1234",
            "timeSlots": [],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_invalid_date_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Bad Date",
            "description": "",
            "passphrase": "admin1234",
            "timeSlots": [{"date": "2030-13-40", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_invalid_time_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Bad Time",
            "description": "",
            "passphrase": "admin1234",
            "timeSlots": [{"date": "2030-07-01", "startTime": "25:61"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_non_24h_time_format_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Bad Time Fmt",
            "description": "",
            "passphrase": "admin1234",
            "timeSlots": [{"date": "2030-07-01", "startTime": "10:00 AM"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_empty_title_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "",
            "description": "",
            "passphrase": "admin1234",
            "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_non_iso_date_format_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Bad Format",
            "description": "",
            "passphrase": "admin1234",
            "timeSlots": [{"date": "01/06/2030", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_description_too_long_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Long Desc",
            "description": "d" * 1001,
            "passphrase": "admin1234",
            "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_create_poll_long_passphrase_rejected(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls",
        json={
            "title": "Long Pass",
            "description": "",
            "passphrase": "p" * 101,
            "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400


def test_get_poll_returns_expected_shape(make_poll, server_url):
    poll = make_poll(title="Shape Test", description="desc")
    detail = poll["detail"]
    assert detail["id"] == poll["pollId"]
    assert detail["title"] == "Shape Test"
    assert detail["description"] == "desc"
    assert detail["closed"] is False
    assert isinstance(detail["timeSlots"], list) and len(detail["timeSlots"]) >= 1
    assert isinstance(detail["responses"], list)
    for slot in detail["timeSlots"]:
        assert isinstance(slot["id"], str)
        assert "date" in slot and "startTime" in slot


def test_get_poll_slots_sorted_by_date_then_time(make_poll):
    poll = make_poll(
        slots=[
            {"date": "2030-08-02", "startTime": "09:00"},
            {"date": "2030-08-01", "startTime": "15:00"},
            {"date": "2030-08-01", "startTime": "09:00"},
        ]
    )
    slots = poll["detail"]["timeSlots"]
    ordered = [(s["date"], s["startTime"]) for s in slots]
    assert ordered == sorted(ordered)


def test_get_poll_nonexistent_returns_404(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.get(f"{server_url}/api/polls/does-not-exist-id", timeout=5)
    assert resp.status_code == 404
    assert resp.json().get("error") == "Poll not found"


def test_submit_response_creates_entries(make_poll, server_url):
    poll = make_poll()
    slot_ids = [s["id"] for s in poll["detail"]["timeSlots"]]
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("alice"),
            "availabilities": [
                {"slotId": slot_ids[0], "availability": "available"},
                {"slotId": slot_ids[1], "availability": "maybe"},
                {"slotId": slot_ids[2], "availability": "unavailable"},
            ],
        },
        timeout=5,
    )
    assert resp.status_code == 201
    ids = resp.json().get("responseIds")
    assert isinstance(ids, list) and len(ids) == 3


def test_submit_response_duplicate_name_rejected(make_poll, server_url):
    poll = make_poll()
    slot_id = poll["detail"]["timeSlots"][0]["id"]
    name = _unique("bob")
    body = {
        "participantName": name,
        "availabilities": [{"slotId": slot_id, "availability": "available"}],
    }
    first = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses", json=body, timeout=5
    )
    assert first.status_code == 201
    second = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses", json=body, timeout=5
    )
    assert second.status_code == 400
    assert second.json().get("error") == "Participant name already exists"


def test_submit_response_missing_participant_name_rejected(make_poll, server_url):
    poll = make_poll()
    slot_id = poll["detail"]["timeSlots"][0]["id"]
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "availabilities": [{"slotId": slot_id, "availability": "available"}],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_submit_response_empty_participant_name_rejected(make_poll, server_url):
    poll = make_poll()
    slot_id = poll["detail"]["timeSlots"][0]["id"]
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": "",
            "availabilities": [{"slotId": slot_id, "availability": "available"}],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_submit_response_long_participant_name_rejected(make_poll, server_url):
    poll = make_poll()
    slot_id = poll["detail"]["timeSlots"][0]["id"]
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": "n" * 101,
            "availabilities": [{"slotId": slot_id, "availability": "available"}],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_submit_response_invalid_availability_value_rejected(make_poll, server_url):
    poll = make_poll()
    slot_id = poll["detail"]["timeSlots"][0]["id"]
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("frank"),
            "availabilities": [{"slotId": slot_id, "availability": "yes"}],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_submit_response_slot_from_other_poll_rejected(make_poll, server_url):
    poll_a = make_poll()
    poll_b = make_poll()
    foreign_slot_id = poll_a["detail"]["timeSlots"][0]["id"]
    resp = requests.post(
        f"{server_url}/api/polls/{poll_b['pollId']}/responses",
        json={
            "participantName": _unique("intruder"),
            "availabilities": [
                {"slotId": foreign_slot_id, "availability": "available"},
            ],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_submit_response_invalid_slot_id_rejected(make_poll, server_url):
    poll = make_poll()
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("eve"),
            "availabilities": [
                {"slotId": "not-a-real-slot-id", "availability": "available"},
            ],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_submit_response_nonexistent_poll_returns_404(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls/nope/responses",
        json={
            "participantName": "ghost",
            "availabilities": [],
        },
        timeout=5,
    )
    assert resp.status_code == 404
    assert resp.json().get("error") == "Poll not found"


def test_get_poll_reflects_submitted_response(make_poll, server_url):
    poll = make_poll()
    slot_ids = [s["id"] for s in poll["detail"]["timeSlots"]]
    name = _unique("carol")
    requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": name,
            "availabilities": [
                {"slotId": slot_ids[0], "availability": "available"},
            ],
        },
        timeout=5,
    )
    detail = requests.get(f"{server_url}/api/polls/{poll['pollId']}", timeout=5).json()
    names = {r["participantName"] for r in detail["responses"]}
    assert name in names
    entry = next(r for r in detail["responses"] if r["participantName"] == name)
    assert isinstance(entry.get("id"), str)
    assert isinstance(entry.get("slotId"), str)
    assert entry.get("availability") in ("available", "maybe", "unavailable")


def test_auth_correct_passphrase_returns_valid(make_poll, server_url):
    poll = make_poll(passphrase="topSecret99")
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/auth",
        json={"passphrase": "topSecret99"},
        timeout=5,
    )
    assert resp.status_code == 200
    assert resp.json().get("valid") is True


def test_auth_wrong_passphrase_returns_403(make_poll, server_url):
    poll = make_poll(passphrase="realpass123")
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/auth",
        json={"passphrase": "wrongpass"},
        timeout=5,
    )
    assert resp.status_code == 403
    assert resp.json().get("error") == "Invalid passphrase"


def test_auth_nonexistent_poll_returns_404(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.post(
        f"{server_url}/api/polls/nonexistent/auth",
        json={"passphrase": "whatever"},
        timeout=5,
    )
    assert resp.status_code == 404
    assert resp.json().get("error") == "Poll not found"


def test_close_poll_returns_winning_slot(make_poll, server_url):
    poll = make_poll(passphrase="closer12345")
    slot_ids = [s["id"] for s in poll["detail"]["timeSlots"]]
    requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("u1"),
            "availabilities": [
                {"slotId": slot_ids[0], "availability": "unavailable"},
                {"slotId": slot_ids[1], "availability": "available"},
                {"slotId": slot_ids[2], "availability": "maybe"},
            ],
        },
        timeout=5,
    )
    requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("u2"),
            "availabilities": [
                {"slotId": slot_ids[0], "availability": "unavailable"},
                {"slotId": slot_ids[1], "availability": "available"},
                {"slotId": slot_ids[2], "availability": "unavailable"},
            ],
        },
        timeout=5,
    )
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/close",
        json={"passphrase": "closer12345"},
        timeout=5,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body.get("closed") is True
    winning = body.get("winningSlot")
    assert winning is not None
    assert winning.get("id") == slot_ids[1]
    assert "date" in winning and "startTime" in winning
    assert isinstance(winning.get("availableCount"), (int, float))
    assert winning["availableCount"] == 2


def test_close_poll_tie_broken_by_earliest_date(make_poll, server_url):
    poll = make_poll(
        passphrase="tiedate12345",
        slots=[
            {"date": "2030-09-02", "startTime": "09:00"},
            {"date": "2030-09-01", "startTime": "09:00"},
        ],
    )
    slots = poll["detail"]["timeSlots"]
    earliest = next(s for s in slots if s["date"] == "2030-09-01")
    other = next(s for s in slots if s["date"] == "2030-09-02")
    requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("p"),
            "availabilities": [
                {"slotId": earliest["id"], "availability": "available"},
                {"slotId": other["id"], "availability": "available"},
            ],
        },
        timeout=5,
    )
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/close",
        json={"passphrase": "tiedate12345"},
        timeout=5,
    )
    assert resp.status_code == 200
    assert resp.json()["winningSlot"]["id"] == earliest["id"]


def test_close_poll_tie_broken_by_earliest_start_time(make_poll, server_url):
    poll = make_poll(
        passphrase="tietime12345",
        slots=[
            {"date": "2030-10-01", "startTime": "15:30"},
            {"date": "2030-10-01", "startTime": "08:00"},
        ],
    )
    slots = poll["detail"]["timeSlots"]
    earliest = next(s for s in slots if s["startTime"] == "08:00")
    other = next(s for s in slots if s["startTime"] == "15:30")
    requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("p"),
            "availabilities": [
                {"slotId": earliest["id"], "availability": "available"},
                {"slotId": other["id"], "availability": "available"},
            ],
        },
        timeout=5,
    )
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/close",
        json={"passphrase": "tietime12345"},
        timeout=5,
    )
    assert resp.status_code == 200
    assert resp.json()["winningSlot"]["id"] == earliest["id"]


def test_close_poll_wrong_passphrase_returns_403(make_poll, server_url):
    poll = make_poll(passphrase="rightpass99")
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/close",
        json={"passphrase": "nope"},
        timeout=5,
    )
    assert resp.status_code == 403
    assert resp.json().get("error") == "Invalid passphrase"


def test_close_poll_nonexistent_returns_404(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.put(
        f"{server_url}/api/polls/nope/close",
        json={"passphrase": "any"},
        timeout=5,
    )
    assert resp.status_code == 404
    assert resp.json().get("error") == "Poll not found"


def test_closed_poll_rejects_new_responses(make_poll, server_url):
    poll = make_poll(passphrase="closeme12345")
    slot_id = poll["detail"]["timeSlots"][0]["id"]
    requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/close",
        json={"passphrase": "closeme12345"},
        timeout=5,
    )
    resp = requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": _unique("late"),
            "availabilities": [{"slotId": slot_id, "availability": "available"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400
    assert isinstance(resp.json().get("error"), str)


def test_add_time_slots_succeeds(make_poll, server_url):
    poll = make_poll(passphrase="addslot12345")
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/slots",
        json={
            "passphrase": "addslot12345",
            "timeSlots": [{"date": "2030-11-15", "startTime": "12:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 201
    ids = resp.json().get("slotIds")
    assert isinstance(ids, list) and len(ids) == 1
    detail = requests.get(f"{server_url}/api/polls/{poll['pollId']}", timeout=5).json()
    assert any(s["date"] == "2030-11-15" and s["startTime"] == "12:00" for s in detail["timeSlots"])


def test_add_time_slots_invalid_date_format_rejected(make_poll, server_url):
    poll = make_poll(passphrase="addfmtdate12")
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/slots",
        json={
            "passphrase": "addfmtdate12",
            "timeSlots": [{"date": "01/06/2030", "startTime": "10:00"}],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_add_time_slots_invalid_time_format_rejected(make_poll, server_url):
    poll = make_poll(passphrase="addfmttime12")
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/slots",
        json={
            "passphrase": "addfmttime12",
            "timeSlots": [{"date": "2030-11-15", "startTime": "25:61"}],
        },
        timeout=5,
    )
    assert 400 <= resp.status_code < 500
    assert isinstance(resp.json().get("error"), str)


def test_add_time_slots_wrong_passphrase_returns_403(make_poll, server_url):
    poll = make_poll(passphrase="realpass123")
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/slots",
        json={
            "passphrase": "wrong",
            "timeSlots": [{"date": "2030-11-15", "startTime": "12:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 403
    assert resp.json().get("error") == "Invalid passphrase"


def test_add_time_slots_nonexistent_poll_returns_404(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.put(
        f"{server_url}/api/polls/nope/slots",
        json={
            "passphrase": "any",
            "timeSlots": [{"date": "2030-11-15", "startTime": "12:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 404
    assert resp.json().get("error") == "Poll not found"


def test_add_time_slots_on_closed_poll_rejected(make_poll, server_url):
    poll = make_poll(passphrase="closeslot123")
    requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/close",
        json={"passphrase": "closeslot123"},
        timeout=5,
    )
    resp = requests.put(
        f"{server_url}/api/polls/{poll['pollId']}/slots",
        json={
            "passphrase": "closeslot123",
            "timeSlots": [{"date": "2030-11-15", "startTime": "12:00"}],
        },
        timeout=5,
    )
    assert resp.status_code == 400
    assert isinstance(resp.json().get("error"), str)


def test_delete_participant_responses_succeeds(make_poll, server_url):
    poll = make_poll(passphrase="delpart12345")
    slot_id = poll["detail"]["timeSlots"][0]["id"]
    name = _unique("dave")
    requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": name,
            "availabilities": [{"slotId": slot_id, "availability": "available"}],
        },
        timeout=5,
    )
    resp = requests.delete(
        f"{server_url}/api/polls/{poll['pollId']}/responses/{name}",
        headers={"X-Passphrase": "delpart12345"},
        timeout=5,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body.get("deleted"), (int, float))
    assert body["deleted"] >= 1
    detail = requests.get(f"{server_url}/api/polls/{poll['pollId']}", timeout=5).json()
    remaining = {r["participantName"] for r in detail["responses"]}
    assert name not in remaining


def test_delete_nonexistent_participant_returns_zero(make_poll, server_url):
    poll = make_poll(passphrase="delnone12345")
    resp = requests.delete(
        f"{server_url}/api/polls/{poll['pollId']}/responses/{_unique('ghost')}",
        headers={"X-Passphrase": "delnone12345"},
        timeout=5,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body.get("deleted"), (int, float))
    assert body["deleted"] == 0


def test_delete_participant_wrong_passphrase_returns_403(make_poll, server_url):
    poll = make_poll(passphrase="realpass456")
    resp = requests.delete(
        f"{server_url}/api/polls/{poll['pollId']}/responses/someone",
        headers={"X-Passphrase": "wrong"},
        timeout=5,
    )
    assert resp.status_code == 403
    assert resp.json().get("error") == "Invalid passphrase"


def test_delete_participant_nonexistent_poll_returns_404(server_url):
    assert server_url is not None, "Server is not running"
    resp = requests.delete(
        f"{server_url}/api/polls/nope/responses/anyone",
        headers={"X-Passphrase": "any"},
        timeout=5,
    )
    assert resp.status_code == 404
    assert resp.json().get("error") == "Poll not found"


def test_passphrase_stored_as_plaintext(make_poll, server_url):
    plain = f"plainpass-{uuid.uuid4().hex[:8]}"
    make_poll(passphrase=plain)
    db_path = os.path.join(_project_dir(), "polls.db")
    conn = sqlite3.connect(db_path)
    try:
        found = False
        tables = [
            r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        ]
        for tname in tables:
            cols = [c[1] for c in conn.execute(f"PRAGMA table_info('{tname}')").fetchall()]
            if not cols:
                continue
            where = " OR ".join([f'"{c}" = ?' for c in cols])
            try:
                row = conn.execute(
                    f"SELECT 1 FROM '{tname}' WHERE {where} LIMIT 1",
                    tuple(plain for _ in cols),
                ).fetchone()
            except sqlite3.Error:
                continue
            if row is not None:
                found = True
                break
    finally:
        conn.close()
    assert found, "Passphrase not found stored as plaintext in any DB column"


def test_delete_response_count_equals_slot_count(make_poll, server_url):
    poll = make_poll(passphrase="delcount1234")
    slot_ids = [s["id"] for s in poll["detail"]["timeSlots"]]
    name = _unique("multi")
    requests.post(
        f"{server_url}/api/polls/{poll['pollId']}/responses",
        json={
            "participantName": name,
            "availabilities": [
                {"slotId": sid, "availability": "available"} for sid in slot_ids
            ],
        },
        timeout=5,
    )
    resp = requests.delete(
        f"{server_url}/api/polls/{poll['pollId']}/responses/{name}",
        headers={"X-Passphrase": "delcount1234"},
        timeout=5,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body.get("deleted"), (int, float))
    assert body["deleted"] == len(slot_ids)


def test_poll_expiration_cleanup_deletes_stale_polls(tmp_path):
    project_dir = _project_dir()
    entry = os.path.join(project_dir, "server", "src", "index.ts")
    assert os.path.exists(entry), f"Server entry not found at {entry}"

    env = os.environ.copy()
    env["POLL_PROJECT_ROOT"] = str(tmp_path)
    env["PORT"] = "3101"
    url = "http://127.0.0.1:3101"

    def _spawn():
        return subprocess.Popen(
            ["node", "--import", "tsx", "server/src/index.ts"],
            cwd=project_dir,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def _wait_ready(timeout=25.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                requests.get(f"{url}/api/polls/__probe__", timeout=1)
                return True
            except Exception:
                time.sleep(0.2)
        return False

    proc = _spawn()
    try:
        assert _wait_ready(), "Isolated server did not start (first)"
        resp = requests.post(
            f"{url}/api/polls",
            json={
                "title": "Stale Poll",
                "description": "",
                "passphrase": "stale1234",
                "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
            },
            timeout=5,
        )
        assert resp.status_code == 201
        stale_id = resp.json()["pollId"]

        resp = requests.post(
            f"{url}/api/polls",
            json={
                "title": "Fresh Poll",
                "description": "",
                "passphrase": "fresh1234",
                "timeSlots": [{"date": "2030-07-01", "startTime": "10:00"}],
            },
            timeout=5,
        )
        assert resp.status_code == 201
        fresh_id = resp.json()["pollId"]
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()

    db_path = str(tmp_path / "polls.db")
    assert os.path.exists(db_path)
    conn = sqlite3.connect(db_path)
    try:
        polls_table = _find_polls_table(conn)
        assert polls_table is not None
        stale_ts = "2020-01-01T00:00:00.000Z"
        conn.execute(
            f"UPDATE '{polls_table}' SET lastActivityAt = ? WHERE id = ?",
            (stale_ts, stale_id),
        )
        conn.commit()
    finally:
        conn.close()

    proc = _spawn()
    try:
        assert _wait_ready(), "Isolated server did not start (second)"
        stale_resp = requests.get(f"{url}/api/polls/{stale_id}", timeout=5)
        fresh_resp = requests.get(f"{url}/api/polls/{fresh_id}", timeout=5)
        assert stale_resp.status_code == 404
        assert fresh_resp.status_code == 200
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()

    conn = sqlite3.connect(db_path)
    try:
        total_child_rows = 0
        for (tname,) in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall():
            if tname == polls_table:
                continue
            try:
                n = conn.execute(f"SELECT COUNT(*) FROM '{tname}'").fetchone()[0]
                total_child_rows += n
            except sqlite3.Error:
                pass
    finally:
        conn.close()
    assert total_child_rows < 2, (
        f"Expected cascade delete to remove stale poll's child rows, "
        f"but found {total_child_rows} non-polls rows remaining "
        f"(foreign_keys may be OFF)"
    )


def test_spa_fallback_returns_html_for_client_route(server_url):
    assert server_url is not None, "Server is not running"
    public_dir = os.path.join(_project_dir(), "server", "public")
    index_path = os.path.join(public_dir, "index.html")
    created_dir = False
    created_file = False
    if not os.path.isdir(public_dir):
        os.makedirs(public_dir, exist_ok=True)
        created_dir = True
    if not os.path.exists(index_path):
        with open(index_path, "w", encoding="utf-8") as f:
            f.write("<!doctype html><html><body>spa</body></html>")
        created_file = True
    try:
        resp = requests.get(f"{server_url}/poll/{uuid.uuid4()}", timeout=5)
        assert resp.status_code == 200
        content_type = resp.headers.get("Content-Type", "").lower()
        body = resp.text.lower()
        assert "html" in content_type or "<html" in body or "<!doctype html" in body
    finally:
        if created_file and os.path.exists(index_path):
            try:
                os.remove(index_path)
            except OSError:
                pass
        if created_dir and os.path.isdir(public_dir):
            try:
                os.rmdir(public_dir)
            except OSError:
                pass
