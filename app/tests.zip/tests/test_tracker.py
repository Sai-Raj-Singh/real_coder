"""Behavioral F2P tests for the freelance time tracking CLI.

Every assertion in this file maps to an explicit requirement of the
prompt (commands, exit codes, persisted schema, color tokens, sort
order, report filters, error routing). Nothing tests internal function
names, module layout, column widths, or any implementation detail that
the prompt does not mandate.
"""

import json
import re
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths and constants
# ---------------------------------------------------------------------------

TRACKER_DIR = Path(__file__).resolve().parent.parent
TRACKER_PATH = TRACKER_DIR / "tracker.py"

# ISO 8601 with second precision — format mandated by the prompt.
TIME_FMT = "%Y-%m-%dT%H:%M:%S"
TS_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$")

# Duration token format (e.g., "1h 2m 3s") — the prompt prescribes integer
# H/M/S tokens with these literal unit letters.
DURATION_REGEX = re.compile(r"\d+h\s+\d+m\s+\d+s")

# ANSI escape sequences listed verbatim in the prompt.
CYAN = "\x1b[36m"
GREEN = "\x1b[32m"
RED = "\x1b[31m"
YELLOW = "\x1b[33m"
RESET = "\x1b[0m"

ANSI_ESCAPE = re.compile(r"\x1b\[\d+m")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def strip_ansi(text):
    """Remove ANSI color escape sequences so plain-text assertions can run
    without coupling to the exact placement of color tokens."""
    return ANSI_ESCAPE.sub("", text)


def run_tracker(cwd, *args):
    """Invoke ``python tracker.py <args>`` inside ``cwd`` and capture output."""
    return subprocess.run(
        [sys.executable, str(TRACKER_PATH), *args],
        cwd=str(cwd),
        capture_output=True,
        text=True,
    )


def read_log(cwd):
    """Parse ``time_log.json`` from ``cwd`` back into a Python list."""
    with open(cwd / "time_log.json") as f:
        return json.load(f)


def write_log(cwd, sessions):
    """Seed ``time_log.json`` in ``cwd`` with the given session list."""
    with open(cwd / "time_log.json", "w") as f:
        json.dump(sessions, f, indent=2)
        f.write("\n")


def fmt_ts(dt):
    """Render a datetime as an ISO 8601 second-precision string."""
    return dt.replace(microsecond=0).strftime(TIME_FMT)


def today_at(hour=10, minute=0):
    """Return today's local date at the given clock time."""
    return datetime.now().replace(hour=hour, minute=minute, second=0, microsecond=0)


# ---------------------------------------------------------------------------
# Module / main entry point
# ---------------------------------------------------------------------------

def _import_tracker():
    """Import ``tracker`` cleanly, turning ImportError into an assertion
    failure so the test reports FAIL instead of ERROR on an empty codebase."""
    if str(TRACKER_DIR) not in sys.path:
        sys.path.insert(0, str(TRACKER_DIR))
    sys.modules.pop("tracker", None)
    try:
        import tracker as _tracker
    except Exception as exc:
        assert False, f"tracker module could not be imported: {exc}"
    return _tracker


def test_tracker_module_is_importable():
    """The ``tracker`` module must expose a callable ``main`` function."""
    tracker = _import_tracker()
    assert callable(tracker.main)


def test_main_returns_int_exit_code():
    """``main`` must return an integer exit code as its contract."""
    tracker = _import_tracker()
    result = tracker.main([])
    assert isinstance(result, int)


# ---------------------------------------------------------------------------
# Invalid invocations — exit code 2, error on stderr, log file untouched
# ---------------------------------------------------------------------------

def test_no_args_exits_with_invalid_code(tmp_path):
    result = run_tracker(tmp_path)
    assert result.returncode == 2
    assert RED in result.stderr


def test_no_args_error_colored_red(tmp_path):
    result = run_tracker(tmp_path)
    assert RED in result.stderr


def test_invalid_usage_error_contains_literal_phrase(tmp_path):
    # Prompt: invalid invocations MUST print "Error: invalid usage" to stderr.
    result = run_tracker(tmp_path, "bogus")
    assert "Error: invalid usage" in strip_ansi(result.stderr)


def test_unknown_command_exits_invalid(tmp_path):
    result = run_tracker(tmp_path, "bogus")
    assert result.returncode == 2
    assert RED in result.stderr


def test_start_without_project_is_invalid(tmp_path):
    result = run_tracker(tmp_path, "start")
    assert result.returncode == 2
    assert RED in result.stderr


def test_start_with_empty_project_is_invalid(tmp_path):
    result = run_tracker(tmp_path, "start", "")
    assert result.returncode == 2
    assert RED in result.stderr


def test_start_with_too_many_arguments_is_invalid(tmp_path):
    # Prompt: start requires "exactly one non-empty project argument".
    result = run_tracker(tmp_path, "start", "Alpha", "Beta")
    assert result.returncode == 2
    assert RED in result.stderr


def test_stop_with_extra_argument_is_invalid(tmp_path):
    result = run_tracker(tmp_path, "stop", "extra")
    assert result.returncode == 2
    assert RED in result.stderr


def test_status_with_extra_argument_is_invalid(tmp_path):
    result = run_tracker(tmp_path, "status", "extra")
    assert result.returncode == 2
    assert RED in result.stderr


def test_report_without_subcommand_is_invalid(tmp_path):
    result = run_tracker(tmp_path, "report")
    assert result.returncode == 2
    assert RED in result.stderr


def test_report_unknown_subcommand_is_invalid(tmp_path):
    result = run_tracker(tmp_path, "report", "month")
    assert result.returncode == 2
    assert RED in result.stderr


def test_report_day_with_extra_argument_is_invalid(tmp_path):
    # Prompt: "report day with no further arguments".
    result = run_tracker(tmp_path, "report", "day", "extra")
    assert result.returncode == 2
    assert RED in result.stderr


def test_report_week_with_extra_argument_is_invalid(tmp_path):
    # Prompt: "report week with no further arguments".
    result = run_tracker(tmp_path, "report", "week", "extra")
    assert result.returncode == 2
    assert RED in result.stderr


def test_invalid_invocation_does_not_create_log(tmp_path):
    result = run_tracker(tmp_path, "bogus")
    # Tracker must actually run (red error on stderr) AND must not create the log.
    assert RED in result.stderr
    assert not (tmp_path / "time_log.json").exists()


def test_invalid_invocation_does_not_modify_existing_log(tmp_path):
    seed = [{"project": "Seeded", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))}]
    write_log(tmp_path, seed)
    before = (tmp_path / "time_log.json").read_bytes()
    result = run_tracker(tmp_path, "bogus")
    after = (tmp_path / "time_log.json").read_bytes()
    assert RED in result.stderr
    assert before == after


# ---------------------------------------------------------------------------
# start command
# ---------------------------------------------------------------------------

def test_start_first_call_creates_log_file(tmp_path):
    assert not (tmp_path / "time_log.json").exists()
    result = run_tracker(tmp_path, "start", "Alpha")
    assert result.returncode == 0
    assert (tmp_path / "time_log.json").exists()


def test_start_success_exit_code_zero(tmp_path):
    result = run_tracker(tmp_path, "start", "Alpha")
    assert result.returncode == 0


def test_start_persists_session_with_required_keys(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    log = read_log(tmp_path)
    assert isinstance(log, list)
    assert len(log) == 1
    session = log[0]
    # Prompt: "Each session object MUST contain exactly three keys".
    assert set(session.keys()) == {"project", "start", "end"}


def test_start_records_project_name(tmp_path):
    run_tracker(tmp_path, "start", "MyProject")
    log = read_log(tmp_path)
    assert log[-1]["project"] == "MyProject"


def test_start_sets_end_to_null_while_running(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    log = read_log(tmp_path)
    assert log[-1]["end"] is None


def test_start_timestamp_is_iso_second_precision(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    log = read_log(tmp_path)
    assert TS_REGEX.match(log[-1]["start"])


def test_start_duplicate_timer_fails_with_exit_one(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "start", "Beta")
    assert result.returncode == 1


def test_start_duplicate_error_colored_red(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "start", "Beta")
    assert RED in result.stderr


def test_start_duplicate_error_names_existing_project(tmp_path):
    # Prompt: "Error: a timer is already running for project '<existing project>'".
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "start", "Beta")
    assert "Alpha" in strip_ansi(result.stderr)


def test_start_duplicate_error_contains_literal_phrase(tmp_path):
    # Prompt: "Error: a timer is already running for project '<existing project>'".
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "start", "Beta")
    assert "Error: a timer is already running" in strip_ansi(result.stderr)


def test_start_duplicate_does_not_modify_file(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    before = (tmp_path / "time_log.json").read_bytes()
    run_tracker(tmp_path, "start", "Beta")
    after = (tmp_path / "time_log.json").read_bytes()
    assert before == after


def test_start_success_message_uses_cyan_for_project(tmp_path):
    result = run_tracker(tmp_path, "start", "Alpha")
    assert CYAN in result.stdout
    assert "Alpha" in strip_ansi(result.stdout)


def test_start_success_message_contains_literal_phrase(tmp_path):
    # Prompt: "Started timer for <project>" on stdout.
    result = run_tracker(tmp_path, "start", "Alpha")
    assert "Started timer for" in strip_ansi(result.stdout)


def test_log_file_ends_with_newline(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    # Prompt: "written with indent=2 and a trailing newline".
    content = (tmp_path / "time_log.json").read_bytes()
    assert content.endswith(b"\n")


def test_start_appends_rather_than_overwriting(tmp_path):
    seed = [{"project": "Old", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))}]
    write_log(tmp_path, seed)
    run_tracker(tmp_path, "start", "New")
    log = read_log(tmp_path)
    projects = [s["project"] for s in log]
    assert "Old" in projects
    assert "New" in projects
    assert len(log) == 2


# ---------------------------------------------------------------------------
# stop command
# ---------------------------------------------------------------------------

def test_stop_success_exit_code_zero(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "stop")
    assert result.returncode == 0


def test_stop_sets_end_to_iso_string(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    run_tracker(tmp_path, "stop")
    log = read_log(tmp_path)
    assert isinstance(log[-1]["end"], str)
    assert TS_REGEX.match(log[-1]["end"])


def test_stop_with_no_running_timer_exits_one(tmp_path):
    result = run_tracker(tmp_path, "stop")
    assert result.returncode == 1


def test_stop_no_running_error_colored_red(tmp_path):
    result = run_tracker(tmp_path, "stop")
    assert RED in result.stderr


def test_stop_no_running_error_contains_literal_phrase(tmp_path):
    # Prompt: "Error: no timer is currently running" on stderr.
    result = run_tracker(tmp_path, "stop")
    assert "Error: no timer is currently running" in strip_ansi(result.stderr)


def test_stop_without_log_file_exits_one(tmp_path):
    assert not (tmp_path / "time_log.json").exists()
    result = run_tracker(tmp_path, "stop")
    assert result.returncode == 1


def test_stop_message_contains_project_in_cyan_and_duration_in_green(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "stop")
    assert CYAN in result.stdout
    assert GREEN in result.stdout
    assert "Alpha" in strip_ansi(result.stdout)


def test_stop_message_renders_duration_h_m_s(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "stop")
    assert DURATION_REGEX.search(strip_ansi(result.stdout))


def test_stop_success_message_contains_literal_phrase(tmp_path):
    # Prompt: "Stopped timer for <project> (<H>h <M>m <S>s)" on stdout.
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "stop")
    assert "Stopped timer for" in strip_ansi(result.stdout)


def test_stop_message_wraps_duration_in_parentheses(tmp_path):
    # Prompt mandates the parenthesized duration token "(<H>h <M>m <S>s)".
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "stop")
    plain = strip_ansi(result.stdout)
    assert re.search(r"\(\d+h\s+\d+m\s+\d+s\)", plain)


def test_stop_preserves_previously_completed_sessions(tmp_path):
    seed = [
        {"project": "Old", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))},
        {"project": "Current", "start": fmt_ts(today_at(10)), "end": None},
    ]
    write_log(tmp_path, seed)
    run_tracker(tmp_path, "stop")
    log = read_log(tmp_path)
    assert len(log) == 2
    old = next(s for s in log if s["project"] == "Old")
    current = next(s for s in log if s["project"] == "Current")
    assert old["end"] == fmt_ts(today_at(9))
    assert isinstance(current["end"], str)


# ---------------------------------------------------------------------------
# status command
# ---------------------------------------------------------------------------

def test_status_when_idle_exits_zero(tmp_path):
    result = run_tracker(tmp_path, "status")
    assert result.returncode == 0


def test_status_when_idle_shows_idle_message(tmp_path):
    result = run_tracker(tmp_path, "status")
    assert "No timer running" in strip_ansi(result.stdout)


def test_status_when_idle_is_yellow(tmp_path):
    result = run_tracker(tmp_path, "status")
    assert YELLOW in result.stdout


def test_status_when_running_exits_zero(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "status")
    assert result.returncode == 0


def test_status_when_running_shows_project_in_cyan(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "status")
    assert CYAN in result.stdout
    assert "Alpha" in strip_ansi(result.stdout)


def test_status_when_running_shows_duration_in_green(tmp_path):
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "status")
    assert GREEN in result.stdout
    assert DURATION_REGEX.search(strip_ansi(result.stdout))


def test_status_when_running_message_contains_literal_phrase(tmp_path):
    # Prompt: "Running: <project> for <H>h <M>m <S>s" on stdout.
    run_tracker(tmp_path, "start", "Alpha")
    result = run_tracker(tmp_path, "status")
    assert "Running:" in strip_ansi(result.stdout)


def test_status_without_log_file_exits_zero(tmp_path):
    assert not (tmp_path / "time_log.json").exists()
    result = run_tracker(tmp_path, "status")
    assert result.returncode == 0


# ---------------------------------------------------------------------------
# report day
# ---------------------------------------------------------------------------

def test_report_day_empty_exits_zero(tmp_path):
    result = run_tracker(tmp_path, "report", "day")
    assert result.returncode == 0


def test_report_day_empty_shows_expected_message(tmp_path):
    result = run_tracker(tmp_path, "report", "day")
    assert "No sessions recorded for today" in strip_ansi(result.stdout)


def test_report_day_empty_is_yellow(tmp_path):
    result = run_tracker(tmp_path, "report", "day")
    assert YELLOW in result.stdout


def test_report_day_lists_every_project_from_today(tmp_path):
    seed = [
        {"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))},
        {"project": "Beta", "start": fmt_ts(today_at(11)), "end": fmt_ts(today_at(12))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    assert "Alpha" in plain
    assert "Beta" in plain


def test_report_day_hours_use_two_decimal_places(tmp_path):
    # 2-hour session → "2.00"
    seed = [{"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    assert "2.00" in plain


def test_report_day_includes_total_label(tmp_path):
    seed = [{"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    assert "TOTAL" in plain


def test_report_day_total_row_shows_summed_hours(tmp_path):
    # Prompt: TOTAL row is "the sum of every data row's hours formatted with
    # exactly two decimal places". Alpha 2h + Beta 3h → 5.00.
    seed = [
        {"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))},
        {"project": "Beta", "start": fmt_ts(today_at(11)), "end": fmt_ts(today_at(14))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    total_line = next(line for line in plain.splitlines() if "TOTAL" in line)
    assert "5.00" in total_line


def test_report_day_sorts_rows_by_hours_descending(tmp_path):
    seed = [
        {"project": "Short", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))},
        {"project": "Long", "start": fmt_ts(today_at(10)), "end": fmt_ts(today_at(13))},
        {"project": "Medium", "start": fmt_ts(today_at(14)), "end": fmt_ts(today_at(16))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    long_pos = plain.find("Long")
    med_pos = plain.find("Medium")
    short_pos = plain.find("Short")
    assert 0 <= long_pos < med_pos < short_pos


def test_report_day_ties_break_by_project_name_ascending(tmp_path):
    seed = [
        {"project": "Beta", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))},
        {"project": "Alpha", "start": fmt_ts(today_at(10)), "end": fmt_ts(today_at(11))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    assert plain.find("Alpha") < plain.find("Beta")


def test_report_day_excludes_sessions_from_other_days(tmp_path):
    yesterday = today_at(10) - timedelta(days=1)
    seed = [
        {"project": "Yesterday", "start": fmt_ts(yesterday), "end": fmt_ts(yesterday + timedelta(hours=2))},
        {"project": "Today", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    assert "Today" in plain
    assert "Yesterday" not in plain


def test_report_day_aggregates_multiple_sessions_for_same_project(tmp_path):
    # Prompt: "sum the total seconds spent per project". Two 1-hour sessions
    # for Alpha on today must total 2.00 hours, not appear as two rows.
    seed = [
        {"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))},
        {"project": "Alpha", "start": fmt_ts(today_at(14)), "end": fmt_ts(today_at(15))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    assert "2.00" in plain


def test_report_day_includes_running_session(tmp_path):
    # A running session whose start falls on today's local date must
    # appear in today's report. Anchoring at today midnight guarantees
    # the start is on today's date regardless of when the test runs.
    start_dt = datetime.combine(datetime.now().date(), datetime.min.time())
    seed = [{"project": "RunningProj", "start": fmt_ts(start_dt), "end": None}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    assert "RunningProj" in plain


def test_report_day_data_rows_use_cyan_and_green(tmp_path):
    seed = [{"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))}]
    write_log(tmp_path, seed)
    stdout = run_tracker(tmp_path, "report", "day").stdout
    assert CYAN in stdout
    assert GREEN in stdout


def test_report_day_header_and_total_use_yellow(tmp_path):
    seed = [{"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))}]
    write_log(tmp_path, seed)
    stdout = run_tracker(tmp_path, "report", "day").stdout
    assert YELLOW in stdout


def test_report_day_header_contains_project_and_hours_labels(tmp_path):
    seed = [{"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    # Prompt: header "containing the column labels `Project` and `Hours`".
    assert "Project" in plain
    assert "Hours" in plain


def test_report_day_has_dash_separator_row(tmp_path):
    seed = [{"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(10))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "day").stdout)
    # Prompt: separator row is "a single line composed solely of dash characters".
    assert any(re.fullmatch(r"-+", line) for line in plain.splitlines())


# ---------------------------------------------------------------------------
# report week
# ---------------------------------------------------------------------------

def test_report_week_empty_exits_zero(tmp_path):
    result = run_tracker(tmp_path, "report", "week")
    assert result.returncode == 0


def test_report_week_empty_shows_expected_message(tmp_path):
    result = run_tracker(tmp_path, "report", "week")
    assert "No sessions recorded for this week" in strip_ansi(result.stdout)


def test_report_week_empty_is_yellow(tmp_path):
    result = run_tracker(tmp_path, "report", "week")
    assert YELLOW in result.stdout


def test_report_week_lists_sessions_from_this_week(tmp_path):
    # Anchor at the current ISO-week Monday so the session is guaranteed in-range
    monday = today_at(10) - timedelta(days=today_at(10).weekday())
    seed = [
        {
            "project": "WeekProj",
            "start": fmt_ts(monday),
            "end": fmt_ts(monday + timedelta(hours=1)),
        }
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "WeekProj" in plain


def test_report_week_excludes_sessions_from_other_weeks(tmp_path):
    # 10 days ago guarantees a session in a prior ISO week regardless of today's weekday.
    old_dt = today_at(10) - timedelta(days=10)
    today_dt = today_at(8)
    seed = [
        {"project": "LastWeek", "start": fmt_ts(old_dt), "end": fmt_ts(old_dt + timedelta(hours=1))},
        {"project": "ThisWeek", "start": fmt_ts(today_dt), "end": fmt_ts(today_dt + timedelta(hours=1))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "ThisWeek" in plain
    assert "LastWeek" not in plain


def test_report_week_includes_total_label(tmp_path):
    today_dt = today_at(8)
    seed = [{"project": "Alpha", "start": fmt_ts(today_dt), "end": fmt_ts(today_dt + timedelta(hours=2))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "TOTAL" in plain


def test_report_week_total_row_shows_summed_hours(tmp_path):
    # Same TOTAL sum invariant as report day, evaluated inside the current
    # ISO week. Alpha 2h + Beta 3h → 5.00.
    base = today_at(8)
    seed = [
        {"project": "Alpha", "start": fmt_ts(base), "end": fmt_ts(base + timedelta(hours=2))},
        {"project": "Beta", "start": fmt_ts(base + timedelta(hours=3)), "end": fmt_ts(base + timedelta(hours=6))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    total_line = next(line for line in plain.splitlines() if "TOTAL" in line)
    assert "5.00" in total_line


def test_report_week_aggregates_multiple_sessions_for_same_project(tmp_path):
    # Prompt: week report follows the same aggregation rules as day. Two
    # 1-hour Alpha sessions in the current week must total 2.00 hours.
    seed = [
        {"project": "Alpha", "start": fmt_ts(today_at(8)), "end": fmt_ts(today_at(9))},
        {"project": "Alpha", "start": fmt_ts(today_at(14)), "end": fmt_ts(today_at(15))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "2.00" in plain


def test_report_week_hours_use_two_decimal_places(tmp_path):
    today_dt = today_at(8)
    seed = [{"project": "Alpha", "start": fmt_ts(today_dt), "end": fmt_ts(today_dt + timedelta(hours=2))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "2.00" in plain


def test_report_week_sorts_rows_by_hours_descending(tmp_path):
    base = today_at(8)
    seed = [
        {"project": "Short", "start": fmt_ts(base), "end": fmt_ts(base + timedelta(hours=1))},
        {"project": "Long", "start": fmt_ts(base + timedelta(hours=2)), "end": fmt_ts(base + timedelta(hours=5))},
        {"project": "Medium", "start": fmt_ts(base + timedelta(hours=6)), "end": fmt_ts(base + timedelta(hours=8))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    long_pos = plain.find("Long")
    med_pos = plain.find("Medium")
    short_pos = plain.find("Short")
    assert 0 <= long_pos < med_pos < short_pos


def test_report_week_ties_break_by_project_name_ascending(tmp_path):
    base = today_at(8)
    seed = [
        {"project": "Beta", "start": fmt_ts(base), "end": fmt_ts(base + timedelta(hours=1))},
        {"project": "Alpha", "start": fmt_ts(base + timedelta(hours=2)), "end": fmt_ts(base + timedelta(hours=3))},
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert plain.find("Alpha") < plain.find("Beta")


def test_report_week_data_rows_use_cyan_and_green(tmp_path):
    today_dt = today_at(8)
    seed = [{"project": "Alpha", "start": fmt_ts(today_dt), "end": fmt_ts(today_dt + timedelta(hours=2))}]
    write_log(tmp_path, seed)
    stdout = run_tracker(tmp_path, "report", "week").stdout
    assert CYAN in stdout
    assert GREEN in stdout


def test_report_week_header_and_total_use_yellow(tmp_path):
    today_dt = today_at(8)
    seed = [{"project": "Alpha", "start": fmt_ts(today_dt), "end": fmt_ts(today_dt + timedelta(hours=2))}]
    write_log(tmp_path, seed)
    stdout = run_tracker(tmp_path, "report", "week").stdout
    assert YELLOW in stdout


def test_report_week_header_contains_project_and_hours_labels(tmp_path):
    today_dt = today_at(8)
    seed = [{"project": "Alpha", "start": fmt_ts(today_dt), "end": fmt_ts(today_dt + timedelta(hours=2))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "Project" in plain
    assert "Hours" in plain


def test_report_week_has_dash_separator_row(tmp_path):
    today_dt = today_at(8)
    seed = [{"project": "Alpha", "start": fmt_ts(today_dt), "end": fmt_ts(today_dt + timedelta(hours=2))}]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert any(re.fullmatch(r"-+", line) for line in plain.splitlines())


def test_report_week_includes_monday_start_of_week(tmp_path):
    # Prompt: ISO week is "Monday 00:00:00 through Sunday 23:59:59".
    # A session stamped at Monday 00:00:00 must be counted.
    today_date = datetime.now().date()
    monday_midnight = datetime.combine(
        today_date - timedelta(days=today_date.weekday()),
        datetime.min.time(),
    )
    seed = [
        {
            "project": "MondayEdge",
            "start": fmt_ts(monday_midnight),
            "end": fmt_ts(monday_midnight + timedelta(hours=1)),
        }
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "MondayEdge" in plain


def test_report_week_includes_sunday_end_of_week(tmp_path):
    # A session that starts at Sunday 23:59:59 is still inside the ISO
    # week window and must be counted.
    today_date = datetime.now().date()
    sunday = today_date + timedelta(days=6 - today_date.weekday())
    sunday_late = datetime.combine(sunday, datetime.min.time()).replace(
        hour=23, minute=59, second=59
    )
    seed = [
        {
            "project": "SundayEdge",
            "start": fmt_ts(sunday_late),
            "end": None,
        }
    ]
    write_log(tmp_path, seed)
    plain = strip_ansi(run_tracker(tmp_path, "report", "week").stdout)
    assert "SundayEdge" in plain


# ---------------------------------------------------------------------------
# Persisted file formatting (indent=2 + trailing newline)
# ---------------------------------------------------------------------------

def test_log_file_is_pretty_printed(tmp_path):
    # Prompt: "written with indent=2". A pretty-printed array with at least
    # one object must span multiple lines.
    run_tracker(tmp_path, "start", "Alpha")
    content = (tmp_path / "time_log.json").read_text()
    assert content.count("\n") >= 2


def test_log_file_uses_two_space_indent(tmp_path):
    # Prompt explicitly specifies indent=2. With that setting the object's
    # opening brace sits two spaces in from the enclosing array. A larger
    # indent value would widen it; indent=None would collapse the file.
    run_tracker(tmp_path, "start", "Alpha")
    content = (tmp_path / "time_log.json").read_text()
    assert "\n  {" in content
