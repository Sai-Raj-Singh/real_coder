package fluenthttp_tests

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"strings"
	"testing"

	"fluenthttp"
)

// The failure-path tests in this file exercise contracts that the library
// MUST satisfy when an assertion fails: the failure is reported through
// t.Errorf, the chained receiver is never nil, and subsequent chained
// methods remain callable. *testing.T is a concrete type that cannot be
// mocked, so running the failing code against the current test's own T
// would mark the test itself failed. The subprocess pattern used here
// re-exec's the test binary filtered to a single helper test; the helper
// runs the failing code and its output is read back, letting the parent
// test observe the failure without inheriting it.

const (
	helperModeEnv       = "FLUENTHTTP_HELPER_MODE"
	helperReachedMarker = "FLUENTHTTP_HELPER_REACHED_END"
	helperNilExpectMark = "FLUENTHTTP_HELPER_NIL_EXPECT"
	helperNilJSONMark   = "FLUENTHTTP_HELPER_NIL_JSON"
)

// unreachableURL starts an httptest.Server and immediately closes it,
// returning its URL. Requests against this URL reliably trigger a
// connection-refused transport error without depending on any external
// network state.
func unreachableURL() string {
	s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	u := s.URL
	s.Close()
	return u
}

// runHelperMode re-invokes the current test binary filtered to
// TestHelper_FailurePath with the given mode in the environment. The
// helper skips unless the mode is set, so a normal go test run does not
// execute its deliberate failures. The returned string is the
// subprocess's combined stdout and stderr.
func runHelperMode(t *testing.T, mode string) string {
	t.Helper()
	cmd := exec.Command(os.Args[0], "-test.run=^TestHelper_FailurePath$", "-test.v")
	cmd.Env = append(os.Environ(), helperModeEnv+"="+mode)
	out, _ := cmd.CombinedOutput()
	return string(out)
}

// assertHelperFailureShape checks the three invariants every
// failure-path helper run must satisfy: no Go panic occurred, the
// helper reported at least one t.Errorf failure, and the helper
// reached its end-of-chain marker (proving every chained method after
// the first failing one was still callable).
func assertHelperFailureShape(t *testing.T, out string) {
	t.Helper()
	if strings.Contains(out, "panic:") {
		t.Errorf("helper panicked during failure-path chain\n%s", out)
	}
	if !strings.Contains(out, "--- FAIL: TestHelper_FailurePath") {
		t.Errorf("expected helper to report a test failure through t.Errorf\n%s", out)
	}
	if !strings.Contains(out, helperReachedMarker) {
		t.Errorf("chain did not reach its end-of-chain marker\n%s", out)
	}
}

// TestHelper_FailurePath is a subprocess helper. Under a normal
// `go test` run it skips; when the parent failure-path tests exec the
// test binary with FLUENTHTTP_HELPER_MODE set, it runs one of four
// failing scenarios and prints a marker so the parent can see the
// chain reached the end.
func TestHelper_FailurePath(t *testing.T) {
	mode := os.Getenv(helperModeEnv)
	if mode == "" {
		t.Skip("subprocess helper invoked by TestFailure_* tests")
	}
	switch mode {
	case "transport":
		c := fluenthttp.NewClient(t, unreachableURL())
		exp := c.Get("/").Expect()
		if exp == nil {
			fmt.Println(helperNilExpectMark)
			return
		}
		exp.Status(http.StatusOK)
		fmt.Println(helperReachedMarker)

	case "jsonparse":
		srv, c := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			_, _ = w.Write([]byte("this body is not valid JSON"))
		}))
		defer srv.Close()
		ja := c.Get("/").Expect().JSON()
		if ja == nil {
			fmt.Println(helperNilJSONMark)
			return
		}
		ja.HasField("anything")
		fmt.Println(helperReachedMarker)

	case "expect_chain":
		srv, c := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("X-Live", "yes")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`ok`))
		}))
		defer srv.Close()
		c.Get("/").Expect().
			Status(999).
			HeaderMatches("X-Live", "yes").
			BodyMatches(`ok`)
		fmt.Println(helperReachedMarker)

	case "json_chain":
		srv, c := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			_, _ = w.Write([]byte(`{"data":[1,2,3]}`))
		}))
		defer srv.Close()
		c.Get("/").Expect().JSON().
			FieldEquals("data", "wrong").
			HasField("data").
			IsArray().
			Length(3)
		fmt.Println(helperReachedMarker)

	case "status_all_fields":
		srv, c := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Y-Resp-Marker", "YMARK_VAL_98765")
			w.WriteHeader(418)
			_, _ = w.Write([]byte("RESPBODY_VAL_54321"))
		}))
		defer srv.Close()
		c.Post("/markerpath").
			WithHeader("X-Req-Marker", "XMARK_VAL_12345").
			WithBody("REQBODY_VAL_67890").
			Expect().
			Status(987)
		fmt.Println(helperReachedMarker)

	case "transport_sentinel":
		c := fluenthttp.NewClient(t, unreachableURL())
		c.Get("/").Expect().Status(http.StatusOK)
		fmt.Println(helperReachedMarker)

	default:
		t.Fatalf("unknown helper mode %q", mode)
	}
}

// TestFailure_TransportErrorReportsAndChains verifies two contracts of
// Request.Expect on a transport error: the failure is reported through
// the bound *testing.T, and a non-nil *Expectation is still returned so
// the subsequent chained Status assertion remains callable.
func TestFailure_TransportErrorReportsAndChains(t *testing.T) {
	out := runHelperMode(t, "transport")
	if strings.Contains(out, helperNilExpectMark) {
		t.Fatalf("Expect() returned nil on transport error; chain cannot continue\n%s", out)
	}
	assertHelperFailureShape(t, out)
}

// TestFailure_JSONParseErrorReportsAndChains verifies two contracts of
// Expectation.JSON on a non-JSON body: the failure is reported through
// t.Errorf, and a non-nil *JSONAssertion is still returned so the
// subsequent chained HasField assertion remains callable.
func TestFailure_JSONParseErrorReportsAndChains(t *testing.T) {
	out := runHelperMode(t, "jsonparse")
	if strings.Contains(out, helperNilJSONMark) {
		t.Fatalf("JSON() returned nil on parse error; chain cannot continue\n%s", out)
	}
	assertHelperFailureShape(t, out)
}

// TestFailure_ExpectationChainContinuesAfterFailedAssertion verifies
// the independent-execution guarantee for *Expectation: a failing
// Status assertion does not prevent subsequent HeaderMatches and
// BodyMatches assertions in the same chain from executing.
func TestFailure_ExpectationChainContinuesAfterFailedAssertion(t *testing.T) {
	out := runHelperMode(t, "expect_chain")
	assertHelperFailureShape(t, out)
}

// TestFailure_JSONAssertionChainContinuesAfterFailedAssertion verifies
// the independent-execution guarantee for *JSONAssertion: a failing
// FieldEquals does not prevent subsequent HasField, IsArray, and
// Length assertions in the same chain from executing.
func TestFailure_JSONAssertionChainContinuesAfterFailedAssertion(t *testing.T) {
	out := runHelperMode(t, "json_chain")
	assertHelperFailureShape(t, out)
}

// TestFailure_StatusFailureMessageContainsAllFields verifies that when
// a Status assertion fails, the failure message reported through
// t.Errorf contains every required slot of content: the expected and
// actual status codes, the request method and path, the request header
// name and value, the retained request body bytes, the response header
// name and value, and the response body bytes. Each slot is checked by
// a distinctive marker value set by the helper so that substring
// presence is unambiguous. Checking the request body specifically
// verifies the body-byte-retention contract: the library must keep the
// request body bytes across the *Expectation lifetime so that every
// failure message can include them verbatim, regardless of whether the
// underlying *http.Request body reader has been consumed by
// (*http.Client).Do.
//
// This test intentionally does NOT check label strings, field order,
// delimiters, or any other formatting choice — only that the required
// CONTENT made it into the message. Format-level invariants (label
// names, consistent ordering across methods) remain a rubric concern.
func TestFailure_StatusFailureMessageContainsAllFields(t *testing.T) {
	out := runHelperMode(t, "status_all_fields")
	// Lower-case the captured output once so every substring check is
	// case-insensitive. The prompt requires the listed CONTENT to appear
	// in the failure message but does not mandate a specific casing for
	// header names; a valid implementation that normalizes header names
	// (e.g. lower-cases them before printing) would otherwise fail this
	// test spuriously. Values and marker tokens are chosen from the
	// ASCII letter-digit-hyphen range where lower-casing is lossless.
	outLower := strings.ToLower(out)
	wantSubstrings := []string{
		"987",                // expected status value
		"418",                // actual status value
		"post",               // request method
		"/markerpath",        // request path
		"x-req-marker",       // request header name
		"xmark_val_12345",    // request header value
		"reqbody_val_67890",  // retained request body bytes
		"y-resp-marker",      // response header name
		"ymark_val_98765",    // response header value
		"respbody_val_54321", // response body bytes
	}
	for _, want := range wantSubstrings {
		if !strings.Contains(outLower, want) {
			t.Errorf("failure message missing required content %q\n%s", want, out)
		}
	}
	assertHelperFailureShape(t, out)
}

// TestFailure_TransportErrorMessageUsesNoneSentinel verifies that when
// Request.Expect encounters a transport error (no *http.Response
// exists), the failure message emitted through t.Errorf contains the
// literal sentinel string "(none)" that the prompt mandates for slots
// without a natural value. The test does not pin which slots carry the
// sentinel — only that at least one slot in the transport-error path
// uses it, which is sufficient to prove the library implements the
// sentinel contract rather than leaving missing slots blank or
// printing a Go zero value.
func TestFailure_TransportErrorMessageUsesNoneSentinel(t *testing.T) {
	out := runHelperMode(t, "transport_sentinel")
	if !strings.Contains(out, "(none)") {
		t.Errorf("transport error failure message did not contain the mandated sentinel \"(none)\"\n%s", out)
	}
	assertHelperFailureShape(t, out)
}
