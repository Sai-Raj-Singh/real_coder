package fluenthttp_tests

import (
	"encoding/json"
	"io"
	"net/http"
	"testing"

	"fluenthttp"
)

// TestStartServer_ReturnsWorkingClient verifies that StartServer yields a
// client that can successfully reach the handler it was started with. This
// exercises StartServer, the returned *Client, and the baseURL wiring end
// to end without inspecting any internal state.
func TestStartServer_ReturnsWorkingClient(t *testing.T) {
	reached := false
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		reached = true
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Get("/").Expect().Status(http.StatusOK)

	if !reached {
		t.Errorf("handler was never reached via StartServer client")
	}
}

// TestTestServer_CloseIsCallable verifies that TestServer exposes a Close
// method that can be invoked without panicking. The prompt requires
// *TestServer to expose Close(); this test is the behavioural check for
// that contract.
func TestTestServer_CloseIsCallable(t *testing.T) {
	srv, _ := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}))
	srv.Close()
}

// TestNewClient_PrefixesBaseURL verifies that calling Get("/foo") on a
// *Client built with NewClient produces a request whose path on the wire
// is the concatenation of the base URL path and "/foo".
func TestNewClient_PrefixesBaseURL(t *testing.T) {
	srv, _ := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/foo" {
			t.Errorf("expected path /foo on the wire, got %q", r.URL.Path)
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	c := fluenthttp.NewClient(t, srv.URL)
	c.Get("/foo").Expect().Status(http.StatusOK)
}

// methodHandler returns a handler that asserts the incoming request uses
// the expected HTTP method and replies 200.
func methodHandler(t *testing.T, expected string) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != expected {
			t.Errorf("expected method %s, got %s", expected, r.Method)
		}
		w.WriteHeader(http.StatusOK)
	})
}

func TestClient_GetSendsGET(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, methodHandler(t, http.MethodGet))
	defer srv.Close()
	client.Get("/").Expect().Status(http.StatusOK)
}

func TestClient_PostSendsPOST(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, methodHandler(t, http.MethodPost))
	defer srv.Close()
	client.Post("/").Expect().Status(http.StatusOK)
}

func TestClient_PutSendsPUT(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, methodHandler(t, http.MethodPut))
	defer srv.Close()
	client.Put("/").Expect().Status(http.StatusOK)
}

func TestClient_PatchSendsPATCH(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, methodHandler(t, http.MethodPatch))
	defer srv.Close()
	client.Patch("/").Expect().Status(http.StatusOK)
}

func TestClient_DeleteSendsDELETE(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, methodHandler(t, http.MethodDelete))
	defer srv.Close()
	client.Delete("/").Expect().Status(http.StatusOK)
}

// TestRequest_WithHeaderSendsHeader verifies that a header added via
// WithHeader arrives at the server.
func TestRequest_WithHeaderSendsHeader(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("X-Custom"); got != "hello" {
			t.Errorf("expected X-Custom=hello, got %q", got)
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Get("/").WithHeader("X-Custom", "hello").Expect().Status(http.StatusOK)
}

// TestRequest_WithCookieSendsCookie verifies that a cookie attached via
// WithCookie arrives at the server readable through (*http.Request).Cookie.
func TestRequest_WithCookieSendsCookie(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie("session")
		if err != nil {
			t.Errorf("expected session cookie, got error %v", err)
			return
		}
		if c.Value != "abc" {
			t.Errorf("expected cookie value 'abc', got %q", c.Value)
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Get("/").
		WithCookie(&http.Cookie{Name: "session", Value: "abc"}).
		Expect().
		Status(http.StatusOK)
}

// TestRequest_WithBodyStringSentVerbatim verifies that a string body is
// sent on the wire byte-for-byte without any wrapping or encoding.
func TestRequest_WithBodyStringSentVerbatim(t *testing.T) {
	const payload = "raw-string-payload-123"
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, err := io.ReadAll(r.Body)
		if err != nil {
			t.Errorf("read body: %v", err)
			return
		}
		if string(body) != payload {
			t.Errorf("expected body %q, got %q", payload, string(body))
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Post("/").WithBody(payload).Expect().Status(http.StatusOK)
}

// TestRequest_WithBodyBytesSentVerbatim verifies that a []byte body is
// sent on the wire byte-for-byte.
func TestRequest_WithBodyBytesSentVerbatim(t *testing.T) {
	payload := []byte{0x01, 0x02, 0x03, 0x04, 0x05}
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, err := io.ReadAll(r.Body)
		if err != nil {
			t.Errorf("read body: %v", err)
			return
		}
		if len(body) != len(payload) {
			t.Errorf("expected %d bytes, got %d", len(payload), len(body))
			return
		}
		for i := range payload {
			if body[i] != payload[i] {
				t.Errorf("byte %d mismatch: expected %#x, got %#x", i, payload[i], body[i])
			}
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Post("/").WithBody(payload).Expect().Status(http.StatusOK)
}

// TestRequest_WithBodyNonRawMarshalsAsJSON verifies that a non-string,
// non-[]byte body is JSON marshaled AND that Content-Type is set to
// "application/json". Both effects are explicit MUST requirements. The
// body is parsed back with encoding/json so the assertion is neutral to
// whitespace, key order, and compact vs indented encoder output.
func TestRequest_WithBodyNonRawMarshalsAsJSON(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if ct := r.Header.Get("Content-Type"); ct != "application/json" {
			t.Errorf("expected Content-Type application/json, got %q", ct)
		}
		raw, err := io.ReadAll(r.Body)
		if err != nil {
			t.Errorf("read body: %v", err)
			return
		}
		var decoded map[string]any
		if err := json.Unmarshal(raw, &decoded); err != nil {
			t.Errorf("body is not valid JSON: %v (body=%q)", err, string(raw))
			return
		}
		if decoded["name"] != "alice" {
			t.Errorf("decoded.name: expected \"alice\", got %v", decoded["name"])
		}
		if n, ok := decoded["n"].(float64); !ok || n != 7 {
			t.Errorf("decoded.n: expected 7, got %v", decoded["n"])
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Post("/").
		WithBody(map[string]any{"name": "alice", "n": 7}).
		Expect().
		Status(http.StatusOK)
}
