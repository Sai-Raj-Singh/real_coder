package fluenthttp_tests

import (
	"net/http"
	"testing"

	"fluenthttp"
)

// TestExpectation_StatusMatch verifies that Status asserts the response
// status code equals the provided value.
func TestExpectation_StatusMatch(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(418)
	}))
	defer srv.Close()

	client.Get("/").Expect().Status(418)
}

// TestExpectation_HeaderMatchesRegex verifies that HeaderMatches checks
// the response header named key against the regular expression pattern.
func TestExpectation_HeaderMatchesRegex(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Thing", "abc-123")
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Get("/").Expect().
		Status(http.StatusOK).
		HeaderMatches("X-Thing", `^abc-\d+$`)
}

// TestExpectation_CookieAssertion verifies that Cookie matches a
// Set-Cookie response header by name and value.
func TestExpectation_CookieAssertion(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.SetCookie(w, &http.Cookie{Name: "session", Value: "xyz"})
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Get("/").Expect().
		Status(http.StatusOK).
		Cookie("session", "xyz")
}

// TestExpectation_BodyMatchesRegex verifies that BodyMatches checks the
// raw response body against the regular expression pattern.
func TestExpectation_BodyMatchesRegex(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("hello world 42"))
	}))
	defer srv.Close()

	client.Get("/").Expect().BodyMatches(`hello \w+ \d+`)
}

// TestExpectation_JSONParsesBody verifies that JSON() returns a
// *JSONAssertion whose scope is the decoded root value.
func TestExpectation_JSONParsesBody(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"foo":"bar"}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldEquals("foo", "bar")
}

// TestExpectation_MultipleAssertionsReuseExpectation verifies that the
// *Expectation returned by Expect() can be used for multiple chained
// assertion calls and still returns a usable receiver each time.
func TestExpectation_MultipleAssertionsReuseExpectation(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Foo", "bar")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()

	exp := client.Get("/").Expect()
	exp.Status(http.StatusOK).
		HeaderMatches("X-Foo", "bar").
		BodyMatches(`"ok":true`)

	ja := exp.JSON()
	ja.FieldEquals("ok", true)
}

// TestRequest_FluentChainMergesAllOptions verifies that a request chain
// that combines headers, cookies, and a body all take effect on the wire.
func TestRequest_FluentChainMergesAllOptions(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("A") != "1" || r.Header.Get("B") != "2" {
			t.Errorf("headers missing from request")
		}
		c, err := r.Cookie("s")
		if err != nil || c.Value != "v" {
			t.Errorf("cookie missing from request")
		}
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	client.Post("/").
		WithHeader("A", "1").
		WithHeader("B", "2").
		WithCookie(&http.Cookie{Name: "s", Value: "v"}).
		WithBody("payload").
		Expect().
		Status(http.StatusOK)
}
