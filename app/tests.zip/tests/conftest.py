import os
import subprocess
import time
import pytest
import requests

_DERIVED_PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_DIR = os.environ.get("POLL_PROJECT_DIR", _DERIVED_PROJECT_DIR)
BASE_URL = "http://127.0.0.1:3000"


def _server_is_up(url: str) -> bool:
    try:
        requests.get(f"{url}/api/polls/__probe__", timeout=1)
        return True
    except Exception:
        return False


def _wait_for_server(url: str, timeout: float = 25.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _server_is_up(url):
            return True
        time.sleep(0.25)
    return False


@pytest.fixture(scope="session")
def server_url():
    entry = os.path.join(PROJECT_DIR, "server", "src", "index.ts")
    if not os.path.exists(entry):
        yield None
        return

    env = os.environ.copy()
    env["PORT"] = "3000"

    try:
        proc = subprocess.Popen(
            ["node", "--import", "tsx", "server/src/index.ts"],
            cwd=PROJECT_DIR,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except (FileNotFoundError, OSError):
        yield None
        return

    if not _wait_for_server(BASE_URL):
        try:
            proc.kill()
        except Exception:
            pass
        yield None
        return

    yield BASE_URL

    try:
        proc.terminate()
        proc.wait(timeout=5)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


@pytest.fixture
def make_poll(server_url):
    def _make(title="Team Sync", description="Weekly meeting", passphrase="secret1234", slots=None):
        assert server_url is not None, "Server is not running"
        if slots is None:
            slots = [
                {"date": "2030-06-01", "startTime": "09:00"},
                {"date": "2030-06-01", "startTime": "10:30"},
                {"date": "2030-06-02", "startTime": "14:00"},
            ]
        resp = requests.post(
            f"{server_url}/api/polls",
            json={
                "title": title,
                "description": description,
                "passphrase": passphrase,
                "timeSlots": slots,
            },
            timeout=5,
        )
        assert resp.status_code == 201, f"Failed to create poll: {resp.status_code} {resp.text}"
        poll_id = resp.json()["pollId"]
        detail = requests.get(f"{server_url}/api/polls/{poll_id}", timeout=5).json()
        return {"pollId": poll_id, "passphrase": passphrase, "detail": detail}

    return _make
