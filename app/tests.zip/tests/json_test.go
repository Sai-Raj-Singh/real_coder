package fluenthttp_tests

import (
	"encoding/json"
	"net/http"
	"testing"

	"fluenthttp"
)

// TestJSON_HasFieldNarrowsScopeToResolvedValue verifies that HasField
// narrows the current scope: after HasField("data") the downstream
// IsArray and Length assertions operate on the resolved array value, not
// on the original root object.
func TestJSON_HasFieldNarrowsScopeToResolvedValue(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"data":[1,2,3,4,5]}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().
		HasField("data").
		IsArray().
		Length(5)
}

// TestJSON_FieldEqualsNumericNormalization verifies that numeric values
// on both sides of FieldEquals are compared as float64 so a Go integer
// literal matches a JSON-decoded number of the same magnitude.
func TestJSON_FieldEqualsNumericNormalization(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"count":42}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldEquals("count", 42)
}

// TestJSON_FieldEqualsFloat verifies float-to-float equality through the
// same numeric normalization path.
func TestJSON_FieldEqualsFloat(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"ratio":3.14}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldEquals("ratio", 3.14)
}

// TestJSON_FieldEqualsString verifies that string equality works through
// FieldEquals (the non-numeric branch).
func TestJSON_FieldEqualsString(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"name":"alice"}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldEquals("name", "alice")
}

// TestJSON_FieldEqualsBoolean verifies that boolean equality works
// through FieldEquals.
func TestJSON_FieldEqualsBoolean(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldEquals("ok", true)
}

// TestJSON_FieldEqualsDoesNotNarrowScope verifies that FieldEquals does
// NOT narrow the current scope: after FieldEquals the subsequent
// HasField("data") still resolves against the original root object.
func TestJSON_FieldEqualsDoesNotNarrowScope(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"count":42,"data":[1,2,3]}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().
		FieldEquals("count", 42).
		HasField("data").
		IsArray().
		Length(3)
}

// TestJSON_FieldMatchesRegex verifies that FieldMatches asserts the
// value at path is a string matching the regular expression pattern.
func TestJSON_FieldMatchesRegex(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"email":"alice@example.com"}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldMatches("email", `^\w+@\w+\.\w+$`)
}

// TestJSON_FieldMatchesDoesNotNarrowScope verifies that FieldMatches does
// NOT narrow the current scope: after FieldMatches the subsequent
// HasField("data") still resolves against the original root object.
func TestJSON_FieldMatchesDoesNotNarrowScope(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"name":"bob","data":[10,20]}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().
		FieldMatches("name", `^bob$`).
		HasField("data").
		IsArray().
		Length(2)
}

// TestJSON_IsArrayOnRoot verifies that IsArray succeeds when the root of
// the decoded JSON value is itself a []any.
func TestJSON_IsArrayOnRoot(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`[1,2,3]`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().IsArray().Length(3)
}

// TestJSON_LengthOnArray verifies that Length succeeds when the current
// scope is a JSON array with the expected element count.
func TestJSON_LengthOnArray(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"items":["a","b","c","d"]}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().HasField("items").Length(4)
}

// TestJSON_PathDotNotationResolvesNestedObjects verifies that dot-
// separated path segments traverse nested object keys.
func TestJSON_PathDotNotationResolvesNestedObjects(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"user":{"profile":{"name":"carol"}}}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldEquals("user.profile.name", "carol")
}

// TestJSON_PathBracketNotationResolvesArrayIndex verifies that bracket
// index segments traverse array elements, including the compound
// "key[i].key" form.
func TestJSON_PathBracketNotationResolvesArrayIndex(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"items":[{"id":1},{"id":2},{"id":3}]}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().FieldEquals("items[1].id", 2)
}

// TestJSON_EmptyPathReferencesCurrentScope verifies that an empty path
// string refers to the current scope itself: after HasField("data")
// narrows scope to a string value, FieldEquals("", "value") compares the
// current scope against the expected value.
func TestJSON_EmptyPathReferencesCurrentScope(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"data":"value"}`))
	}))
	defer srv.Close()

	client.Get("/").Expect().JSON().
		HasField("data").
		FieldEquals("", "value")
}

// TestJSON_SeedChainEndToEnd exercises the full fluent chain from the
// prompt description: status + header + JSON + HasField + IsArray +
// Length, against a realistic JSON payload.
func TestJSON_SeedChainEndToEnd(t *testing.T) {
	srv, client := fluenthttp.StartServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		items := make([]map[string]any, 10)
		for i := range items {
			items[i] = map[string]any{"id": i, "name": "item"}
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"data": items})
	}))
	defer srv.Close()

	client.Get("/").Expect().
		Status(http.StatusOK).
		HeaderMatches("Content-Type", "application/json").
		JSON().
		HasField("data").
		IsArray().
		Length(10)
}
