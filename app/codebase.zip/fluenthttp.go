// Package fluenthttp provides a fluent, chainable test helper for writing HTTP
// integration tests against REST APIs using only the Go standard library and the
// testing package.
package fluenthttp

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"testing"
)

// sentinelNone is the literal placeholder used in failure messages whenever a
// labeled slot has no natural value (transport error before any *http.Response
// exists, JSON parse error before any decoded value exists, JSON path
// resolution error before any value at the path exists, and so on).
const sentinelNone = "(none)"

// Client sends HTTP requests against a fixed base URL and carries the
// *testing.T bound at construction so every downstream stage in the fluent
// chain can report failures without receiving t again.
type Client struct {
	t       *testing.T
	baseURL string
	http    *http.Client
}

// NewClient returns a *Client bound to t that prefixes every request path with
// baseURL and sends requests through net/http.
func NewClient(t *testing.T, baseURL string) *Client {
	return &Client{
		t:       t,
		baseURL: baseURL,
		http:    &http.Client{},
	}
}

// TestServer wraps the started httptest.Server returned by StartServer.
type TestServer struct {
	*httptest.Server
}

// Close shuts down the underlying httptest.Server.
func (ts *TestServer) Close() {
	if ts.Server != nil {
		ts.Server.Close()
	}
}

// StartServer starts an httptest.Server serving handler and returns the
// wrapped server together with a *Client bound to t whose base URL is the
// started server's URL.
func StartServer(t *testing.T, handler http.Handler) (*TestServer, *Client) {
	srv := httptest.NewServer(handler)
	return &TestServer{Server: srv}, NewClient(t, srv.URL)
}

// Get returns a *Request builder configured with method GET and URL baseURL+path.
func (c *Client) Get(path string) *Request { return c.newRequest(http.MethodGet, path) }

// Post returns a *Request builder configured with method POST and URL baseURL+path.
func (c *Client) Post(path string) *Request { return c.newRequest(http.MethodPost, path) }

// Put returns a *Request builder configured with method PUT and URL baseURL+path.
func (c *Client) Put(path string) *Request { return c.newRequest(http.MethodPut, path) }

// Patch returns a *Request builder configured with method PATCH and URL baseURL+path.
func (c *Client) Patch(path string) *Request { return c.newRequest(http.MethodPatch, path) }

// Delete returns a *Request builder configured with method DELETE and URL baseURL+path.
func (c *Client) Delete(path string) *Request { return c.newRequest(http.MethodDelete, path) }

func (c *Client) newRequest(method, path string) *Request {
	return &Request{
		client:  c,
		method:  method,
		url:     c.baseURL + path,
		headers: http.Header{},
	}
}

// Request is a mutable builder holding the accumulated HTTP method, URL,
// headers, cookies, and body for a single outgoing request.
type Request struct {
	client    *Client
	method    string
	url       string
	headers   http.Header
	cookies   []*http.Cookie
	bodyBytes []byte
	hasBody   bool
}

// WithHeader appends an HTTP header to the outgoing request and returns the
// same receiver for chaining.
func (r *Request) WithHeader(key, value string) *Request {
	r.headers.Add(key, value)
	return r
}

// WithCookie attaches the cookie to the outgoing request through
// (*http.Request).AddCookie and returns the same receiver for chaining.
func (r *Request) WithCookie(cookie *http.Cookie) *Request {
	r.cookies = append(r.cookies, cookie)
	return r
}

// WithBody sets the request body and returns the same receiver for chaining.
// A string value is sent verbatim as bytes, a []byte value is sent verbatim,
// and every other value is JSON-marshaled with encoding/json with the request
// header Content-Type set to application/json. The resulting body bytes are
// retained on the request so that every failure message produced by the
// downstream *Expectation can include the request body verbatim regardless of
// whether the outgoing *http.Request body reader has been consumed.
func (r *Request) WithBody(body any) *Request {
	switch v := body.(type) {
	case string:
		r.bodyBytes = []byte(v)
	case []byte:
		r.bodyBytes = append([]byte(nil), v...)
	default:
		marshaled, err := json.Marshal(body)
		if err != nil {
			r.bodyBytes = []byte(fmt.Sprintf("(json marshal error: %s)", err))
		} else {
			r.bodyBytes = marshaled
			r.headers.Set("Content-Type", "application/json")
		}
	}
	r.hasBody = true
	return r
}

// Expect builds the *http.Request, sends it through (*http.Client).Do, reads
// the entire response body into memory, and returns an *Expectation bound to
// the *testing.T inherited from the originating client together with the
// captured request/response pair. Transport errors are reported through
// t.Errorf using the standard failure format, and a non-nil *Expectation is
// still returned so chained assertions remain callable.
func (r *Request) Expect() *Expectation {
	if r.client != nil && r.client.t != nil {
		r.client.t.Helper()
	}
	exp := &Expectation{
		t:            r.client.t,
		reqMethod:    r.method,
		reqURL:       r.url,
		reqHeaders:   cloneHeader(r.headers),
		reqCookies:   append([]*http.Cookie(nil), r.cookies...),
		reqBodyBytes: r.bodyBytes,
	}

	var bodyReader io.Reader
	if r.hasBody {
		bodyReader = bytes.NewReader(r.bodyBytes)
	}
	httpReq, err := http.NewRequest(r.method, r.url, bodyReader)
	if err != nil {
		exp.fail("Expect", "buildable *http.Request", fmt.Sprintf("build error: %s", err))
		return exp
	}
	for key, values := range r.headers {
		for _, value := range values {
			httpReq.Header.Add(key, value)
		}
	}
	for _, cookie := range r.cookies {
		httpReq.AddCookie(cookie)
	}
	exp.req = httpReq

	resp, err := r.client.http.Do(httpReq)
	if err != nil {
		exp.fail("Expect", "successful HTTP transport", fmt.Sprintf("transport error: %s", err))
		return exp
	}
	defer resp.Body.Close()
	respBody, readErr := io.ReadAll(resp.Body)
	exp.resp = resp
	exp.respBodyBytes = respBody
	if readErr != nil {
		exp.fail("Expect", "readable response body", fmt.Sprintf("read error: %s", readErr))
	}
	return exp
}

func cloneHeader(h http.Header) http.Header {
	out := http.Header{}
	for key, values := range h {
		out[key] = append([]string(nil), values...)
	}
	return out
}

// Expectation holds the captured request/response pair and exposes chainable
// assertion methods that report failures through t.Errorf.
type Expectation struct {
	t             *testing.T
	req           *http.Request
	reqMethod     string
	reqURL        string
	reqHeaders    http.Header
	reqCookies    []*http.Cookie
	reqBodyBytes  []byte
	resp          *http.Response
	respBodyBytes []byte
}

// Status asserts the response status code equals code.
func (e *Expectation) Status(code int) *Expectation {
	if e.t != nil {
		e.t.Helper()
	}
	if e.resp == nil {
		e.fail("Status", code, sentinelNone)
		return e
	}
	if e.resp.StatusCode != code {
		e.fail("Status", code, e.resp.StatusCode)
	}
	return e
}

// HeaderMatches asserts the response header named key matches the regular
// expression pattern compiled with regexp.Compile.
func (e *Expectation) HeaderMatches(key, pattern string) *Expectation {
	if e.t != nil {
		e.t.Helper()
	}
	re, err := regexp.Compile(pattern)
	if err != nil {
		e.fail("HeaderMatches",
			fmt.Sprintf("header %q to match /%s/", key, pattern),
			sentinelNone)
		return e
	}
	if e.resp == nil {
		e.fail("HeaderMatches",
			fmt.Sprintf("header %q to match /%s/", key, pattern),
			sentinelNone)
		return e
	}
	got := e.resp.Header.Get(key)
	if !re.MatchString(got) {
		e.fail("HeaderMatches",
			fmt.Sprintf("header %q to match /%s/", key, pattern),
			got)
	}
	return e
}

// Cookie asserts the response contains a Set-Cookie entry whose name is name
// and whose value equals value.
func (e *Expectation) Cookie(name, value string) *Expectation {
	if e.t != nil {
		e.t.Helper()
	}
	if e.resp == nil {
		e.fail("Cookie", fmt.Sprintf("%s=%s", name, value), sentinelNone)
		return e
	}
	for _, c := range e.resp.Cookies() {
		if c.Name == name && c.Value == value {
			return e
		}
	}
	actual := fmt.Sprintf("no Set-Cookie with name %q", name)
	for _, c := range e.resp.Cookies() {
		if c.Name == name {
			actual = fmt.Sprintf("%s=%s", c.Name, c.Value)
			break
		}
	}
	e.fail("Cookie", fmt.Sprintf("%s=%s", name, value), actual)
	return e
}

// BodyMatches asserts the raw response body matches the regular expression
// pattern compiled with regexp.Compile.
func (e *Expectation) BodyMatches(pattern string) *Expectation {
	if e.t != nil {
		e.t.Helper()
	}
	re, err := regexp.Compile(pattern)
	if err != nil {
		e.fail("BodyMatches",
			fmt.Sprintf("body to match /%s/", pattern),
			sentinelNone)
		return e
	}
	if e.resp == nil {
		e.fail("BodyMatches", fmt.Sprintf("body to match /%s/", pattern), sentinelNone)
		return e
	}
	if !re.Match(e.respBodyBytes) {
		e.fail("BodyMatches", fmt.Sprintf("body to match /%s/", pattern), string(e.respBodyBytes))
	}
	return e
}

// JSON parses the response body with encoding/json into an any value and
// returns a *JSONAssertion whose current scope is the root of the decoded
// value. When the body is not valid JSON a failure is reported through
// t.Errorf and a non-nil *JSONAssertion is still returned so chained
// assertions remain callable.
func (e *Expectation) JSON() *JSONAssertion {
	if e.t != nil {
		e.t.Helper()
	}
	ja := &JSONAssertion{parent: e}
	if e.resp == nil {
		e.fail("JSON", "valid JSON body", sentinelNone)
		return ja
	}
	var decoded any
	if err := json.Unmarshal(e.respBodyBytes, &decoded); err != nil {
		e.fail("JSON", "valid JSON body", sentinelNone)
		return ja
	}
	ja.scope = decoded
	ja.hasScope = true
	return ja
}

// JSONAssertion holds a reference to the parent *Expectation and the current
// JSON scope being asserted against, and exposes chainable JSON path assertion
// methods.
type JSONAssertion struct {
	parent   *Expectation
	scope    any
	hasScope bool
}

// HasField asserts the dot-and-bracket JSON path resolves to an existing value
// within the current scope and narrows the receiver's current scope to that
// resolved value so that subsequent chained assertions operate on the resolved
// value rather than the prior scope.
func (j *JSONAssertion) HasField(path string) *JSONAssertion {
	if j.parent != nil && j.parent.t != nil {
		j.parent.t.Helper()
	}
	if !j.hasScope {
		j.parent.fail("HasField", fmt.Sprintf("value at %q", path), sentinelNone)
		return j
	}
	resolved, ok := resolvePath(j.scope, path)
	if !ok {
		j.parent.fail("HasField", fmt.Sprintf("value at %q", path), sentinelNone)
		return j
	}
	j.scope = resolved
	return j
}

// FieldEquals asserts the JSON value at path within the current scope equals
// value, where numeric values on both sides are compared as float64 so that a
// Go integer literal matches a JSON-decoded number with the same magnitude.
// FieldEquals does not narrow the current scope.
func (j *JSONAssertion) FieldEquals(path string, value any) *JSONAssertion {
	if j.parent != nil && j.parent.t != nil {
		j.parent.t.Helper()
	}
	if !j.hasScope {
		j.parent.fail("FieldEquals", fmt.Sprintf("%s == %v", path, value), sentinelNone)
		return j
	}
	got, ok := resolvePath(j.scope, path)
	if !ok {
		j.parent.fail("FieldEquals", fmt.Sprintf("%s == %v", path, value), sentinelNone)
		return j
	}
	if !equalNormalized(got, value) {
		j.parent.fail("FieldEquals",
			fmt.Sprintf("%s == %v", path, value),
			fmt.Sprintf("%s == %v", path, got))
	}
	return j
}

// FieldMatches asserts the JSON value at path within the current scope is a
// string matching the regular expression pattern compiled with regexp.Compile.
// FieldMatches does not narrow the current scope.
func (j *JSONAssertion) FieldMatches(path, pattern string) *JSONAssertion {
	if j.parent != nil && j.parent.t != nil {
		j.parent.t.Helper()
	}
	re, err := regexp.Compile(pattern)
	if err != nil {
		j.parent.fail("FieldMatches",
			fmt.Sprintf("%s to match /%s/", path, pattern),
			sentinelNone)
		return j
	}
	if !j.hasScope {
		j.parent.fail("FieldMatches",
			fmt.Sprintf("%s to match /%s/", path, pattern),
			sentinelNone)
		return j
	}
	got, ok := resolvePath(j.scope, path)
	if !ok {
		j.parent.fail("FieldMatches",
			fmt.Sprintf("%s to match /%s/", path, pattern),
			sentinelNone)
		return j
	}
	asString, isString := got.(string)
	if !isString {
		j.parent.fail("FieldMatches",
			fmt.Sprintf("%s to match /%s/", path, pattern),
			fmt.Sprintf("non-string value: %v", got))
		return j
	}
	if !re.MatchString(asString) {
		j.parent.fail("FieldMatches",
			fmt.Sprintf("%s to match /%s/", path, pattern),
			asString)
	}
	return j
}

// IsArray asserts the current scope is a JSON array (decoded as []any).
func (j *JSONAssertion) IsArray() *JSONAssertion {
	if j.parent != nil && j.parent.t != nil {
		j.parent.t.Helper()
	}
	if !j.hasScope {
		j.parent.fail("IsArray", "[]any", sentinelNone)
		return j
	}
	if _, ok := j.scope.([]any); !ok {
		j.parent.fail("IsArray", "[]any", fmt.Sprintf("%T", j.scope))
	}
	return j
}

// Length asserts the current scope is a JSON array (decoded as []any) whose
// element count equals n.
func (j *JSONAssertion) Length(n int) *JSONAssertion {
	if j.parent != nil && j.parent.t != nil {
		j.parent.t.Helper()
	}
	if !j.hasScope {
		j.parent.fail("Length", n, sentinelNone)
		return j
	}
	arr, ok := j.scope.([]any)
	if !ok {
		j.parent.fail("Length",
			fmt.Sprintf("array of length %d", n),
			fmt.Sprintf("non-array %T", j.scope))
		return j
	}
	if len(arr) != n {
		j.parent.fail("Length", n, len(arr))
	}
	return j
}

// resolvePath walks scope using dot-and-bracket syntax where '.' separates
// object keys and '[i]' indexes into array elements. An empty path refers to
// the current scope itself. Object keys are composed of any characters except
// '.' and '['.
func resolvePath(scope any, path string) (any, bool) {
	if path == "" {
		return scope, true
	}
	current := scope
	i := 0
	for i < len(path) {
		if path[i] == '[' {
			closing := strings.IndexByte(path[i:], ']')
			if closing == -1 {
				return nil, false
			}
			idx, err := strconv.Atoi(path[i+1 : i+closing])
			if err != nil {
				return nil, false
			}
			arr, ok := current.([]any)
			if !ok {
				return nil, false
			}
			if idx < 0 || idx >= len(arr) {
				return nil, false
			}
			current = arr[idx]
			i += closing + 1
			if i < len(path) && path[i] == '.' {
				i++
			}
			continue
		}
		start := i
		for i < len(path) && path[i] != '.' && path[i] != '[' {
			i++
		}
		key := path[start:i]
		obj, ok := current.(map[string]any)
		if !ok {
			return nil, false
		}
		child, exists := obj[key]
		if !exists {
			return nil, false
		}
		current = child
		if i < len(path) && path[i] == '.' {
			i++
		}
	}
	return current, true
}

// equalNormalized compares two values treating numeric kinds as float64 so
// that a Go integer literal matches a JSON-decoded number with the same
// magnitude. Non-numeric values are compared with reflect.DeepEqual.
func equalNormalized(a, b any) bool {
	af, aok := toFloat64(a)
	bf, bok := toFloat64(b)
	if aok && bok {
		return af == bf
	}
	return reflect.DeepEqual(a, b)
}

func toFloat64(v any) (float64, bool) {
	switch n := v.(type) {
	case int:
		return float64(n), true
	case int8:
		return float64(n), true
	case int16:
		return float64(n), true
	case int32:
		return float64(n), true
	case int64:
		return float64(n), true
	case uint:
		return float64(n), true
	case uint8:
		return float64(n), true
	case uint16:
		return float64(n), true
	case uint32:
		return float64(n), true
	case uint64:
		return float64(n), true
	case float32:
		return float64(n), true
	case float64:
		return n, true
	}
	return 0, false
}

// fail reports an assertion failure through the bound *testing.T using the
// standard failure format with byte-for-byte identical labels and ordering
// across every assertion method in the library. It marks itself as a test
// helper so Errorf's reported file:line points at the test's chain call
// rather than at this internal reporting routine.
func (e *Expectation) fail(assertion string, expected, actual any) {
	if e.t == nil {
		return
	}
	e.t.Helper()
	e.t.Errorf("%s", e.formatFailure(assertion, expected, actual))
}

func (e *Expectation) formatFailure(assertion string, expected, actual any) string {
	var b strings.Builder
	fmt.Fprintf(&b, "\nassertion: %s\n", assertion)
	fmt.Fprintf(&b, "expected: %v\n", expected)
	fmt.Fprintf(&b, "actual: %v\n", actual)
	fmt.Fprintf(&b, "request method: %s\n", stringOrNone(e.reqMethod))
	fmt.Fprintf(&b, "request url: %s\n", stringOrNone(e.reqURL))
	b.WriteString("request headers:\n")
	b.WriteString(formatHeaders(e.reqHeaders))
	fmt.Fprintf(&b, "request body: %s\n", bytesOrNone(e.reqBodyBytes))
	if e.resp != nil {
		fmt.Fprintf(&b, "response status: %s\n", e.resp.Status)
		b.WriteString("response headers:\n")
		b.WriteString(formatHeaders(http.Header(e.resp.Header)))
		fmt.Fprintf(&b, "response body: %s\n", bytesOrNone(e.respBodyBytes))
	} else {
		fmt.Fprintf(&b, "response status: %s\n", sentinelNone)
		b.WriteString("response headers:\n")
		b.WriteString("  " + sentinelNone + "\n")
		fmt.Fprintf(&b, "response body: %s\n", sentinelNone)
	}
	return b.String()
}

func stringOrNone(s string) string {
	if s == "" {
		return sentinelNone
	}
	return s
}

func bytesOrNone(b []byte) string {
	if len(b) == 0 {
		return sentinelNone
	}
	return string(b)
}

func formatHeaders(h http.Header) string {
	if len(h) == 0 {
		return "  " + sentinelNone + "\n"
	}
	keys := make([]string, 0, len(h))
	for k := range h {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var b strings.Builder
	for _, k := range keys {
		for _, v := range h[k] {
			fmt.Fprintf(&b, "  %s: %s\n", k, v)
		}
	}
	return b.String()
}
