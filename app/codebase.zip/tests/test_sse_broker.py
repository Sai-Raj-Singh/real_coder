"""
F2P test suite for the SSE Broker Service.

Tests verify observable behavior and public interfaces only -
no implementation details, no hardcoded error messages, no private methods.
Every test maps to an explicit or strongly implicit requirement in the prompt.
"""

import os
import subprocess
import threading
import time
from typing import List, Optional

import pytest
import requests

# -- Build & server lifecycle --------------------------------------------------

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.join(_TEST_DIR, "..")
_BINARY = os.path.join(_PARENT_DIR, "sse_broker")
_PORT = 19876
_BASE: Optional[str] = None
_PROC: Optional[subprocess.Popen] = None


def _build() -> bool:
    result = subprocess.run(
        ["go", "build", "-o", _BINARY, "."],
        cwd=_PARENT_DIR,
        capture_output=True,
    )
    return result.returncode == 0


def _start(port: int, default_history: int = 100) -> Optional[subprocess.Popen]:
    proc = subprocess.Popen(
        [_BINARY, f"--port={port}", f"--default-history-size={default_history}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    deadline = time.time() + 6.0
    while time.time() < deadline:
        try:
            requests.get(f"http://127.0.0.1:{port}/channels", timeout=0.3)
            return proc
        except Exception:
            if proc.poll() is not None:
                return None
            time.sleep(0.15)
    return proc


def _setup_once():
    global _BASE, _PROC
    if not _build():
        return
    proc = _start(_PORT, default_history=100)
    if proc is None or proc.poll() is not None:
        return
    _PROC = proc
    _BASE = f"http://127.0.0.1:{_PORT}"


_setup_once()


def pytest_sessionfinish(session, exitstatus):
    if _PROC is not None:
        _PROC.terminate()
        try:
            _PROC.wait(timeout=3)
        except subprocess.TimeoutExpired:
            _PROC.kill()


# -- Helpers -------------------------------------------------------------------

def _url(path: str) -> str:
    # Calling pytest.fail here ensures FAILED (not ERROR) when server is unavailable
    assert _BASE is not None, "Server not available - build or startup failed"
    return f"{_BASE}{path}"


def _unique() -> str:
    return f"ch-{int(time.time() * 1_000_000) % 999_999_999}-{os.getpid()}"


def _create(channel_id: str, **kwargs) -> requests.Response:
    body = {"channel_id": channel_id}
    body.update(kwargs)
    return requests.post(_url("/channels"), json=body, timeout=5)


def _publish(channel_id: str, data: str, event: Optional[str] = None,
             token: Optional[str] = None) -> requests.Response:
    body = {"data": data}
    if event is not None:
        body["event"] = event
    headers = {}
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    return requests.post(_url(f"/channels/{channel_id}/events"),
                         json=body, headers=headers, timeout=5)


def _collect_sse(channel_id: str, count: int,
                 last_event_id: Optional[str] = None,
                 token: Optional[str] = None,
                 timeout: float = 5.0) -> List[dict]:
    """
    Open an SSE stream and collect up to `count` non-comment event frames.
    Returns a list of dicts with the parsed SSE fields (id, event, data).
    """
    headers = {"Accept": "text/event-stream"}
    if last_event_id is not None:
        headers["Last-Event-ID"] = last_event_id
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"

    events: List[dict] = []
    try:
        with requests.get(_url(f"/channels/{channel_id}/events"),
                          headers=headers, stream=True, timeout=timeout) as resp:
            if resp.status_code != 200:
                return events
            current: dict = {}
            deadline = time.time() + timeout
            for line in resp.iter_lines(decode_unicode=True):
                if time.time() > deadline:
                    break
                if line == "":
                    if current:
                        events.append(current)
                        current = {}
                        if len(events) >= count:
                            break
                elif line.startswith(":"):
                    pass  # SSE comment / keepalive - ignored here
                elif ":" in line:
                    field, _, value = line.partition(":")
                    current[field.strip()] = value.strip()
    except Exception:
        pass
    return events


def _subscribe_raw_lines(channel_id: str, timeout: float = 22.0) -> List[str]:
    """Return all raw lines received within timeout, including comment lines."""
    lines: List[str] = []
    headers = {"Accept": "text/event-stream"}
    try:
        with requests.get(_url(f"/channels/{channel_id}/events"),
                          headers=headers, stream=True, timeout=timeout) as resp:
            if resp.status_code != 200:
                return lines
            deadline = time.time() + timeout
            for line in resp.iter_lines(decode_unicode=True):
                if time.time() > deadline:
                    break
                lines.append(line)
                if any(ln.startswith(":keepalive") for ln in lines):
                    break
    except Exception:
        pass
    return lines


# -----------------------------------------------------------------------------
# TestBrokerConstructor
# Verifies: NewBroker Expected Interface - server is reachable with all routes
# -----------------------------------------------------------------------------

class TestBrokerConstructor:

    def test_server_is_reachable(self):
        resp = requests.get(_url("/channels"), timeout=5)
        # Any response (even 404/405) means the server is up
        assert resp.status_code is not None

    def test_channels_endpoint_exists(self):
        resp = requests.post(_url("/channels"),
                             json={"channel_id": _unique()}, timeout=5)
        assert resp.status_code in (200, 201, 400, 409)

    def test_publish_endpoint_exists(self):
        ch = _unique()
        _create(ch)
        resp = requests.post(_url(f"/channels/{ch}/events"),
                             json={"data": "probe"}, timeout=5)
        assert resp.status_code in (200, 400, 401, 404)

    def test_subscribe_endpoint_exists(self):
        ch = _unique()
        _create(ch)
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.status_code in (200, 401, 404)
        resp.close()


# -----------------------------------------------------------------------------
# TestCreateChannel  (POST /channels)
# -----------------------------------------------------------------------------

class TestCreateChannel:

    def test_valid_creation_returns_201(self):
        resp = _create(_unique())
        assert resp.status_code == 201

    def test_response_body_echoes_channel_id(self):
        ch = _unique()
        resp = _create(ch)
        assert resp.status_code == 201
        assert resp.json().get("channel_id") == ch

    def test_duplicate_channel_returns_409(self):
        ch = _unique()
        assert _create(ch).status_code == 201
        assert _create(ch).status_code == 409

    def test_channel_id_with_space_returns_400(self):
        assert _create("invalid channel").status_code == 400

    def test_channel_id_with_slash_returns_400(self):
        assert _create("foo/bar").status_code == 400

    def test_channel_id_with_dot_returns_400(self):
        assert _create("foo.bar").status_code == 400

    def test_channel_id_with_at_sign_returns_400(self):
        assert _create("foo@bar").status_code == 400

    def test_empty_channel_id_returns_400(self):
        resp = requests.post(_url("/channels"), json={"channel_id": ""}, timeout=5)
        assert resp.status_code == 400

    def test_missing_channel_id_returns_400(self):
        resp = requests.post(_url("/channels"), json={}, timeout=5)
        assert resp.status_code == 400

    def test_history_size_zero_is_valid(self):
        assert _create(_unique(), history_size=0).status_code == 201

    def test_history_size_max_boundary_is_valid(self):
        assert _create(_unique(), history_size=10000).status_code == 201

    def test_history_size_above_max_returns_400(self):
        assert _create(_unique(), history_size=10001).status_code == 400

    def test_history_size_negative_returns_400(self):
        assert _create(_unique(), history_size=-1).status_code == 400

    def test_omitting_history_size_succeeds(self):
        assert _create(_unique()).status_code == 201

    def test_channel_with_both_tokens_succeeds(self):
        assert _create(_unique(),
                       publish_token="p-tok",
                       subscribe_token="s-tok").status_code == 201

    def test_channel_with_only_publish_token_succeeds(self):
        assert _create(_unique(), publish_token="p-only").status_code == 201

    def test_channel_with_only_subscribe_token_succeeds(self):
        assert _create(_unique(), subscribe_token="s-only").status_code == 201

    def test_alphanumeric_underscore_hyphen_channel_id_accepted(self):
        assert _create("Valid-Channel_123").status_code in (201, 409)

    def test_channel_immediately_usable_for_publish_after_creation(self):
        ch = _unique()
        _create(ch)
        assert _publish(ch, "probe").status_code == 200

    def test_channel_immediately_usable_for_subscribe_after_creation(self):
        ch = _unique()
        _create(ch)
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.status_code == 200
        resp.close()


# -----------------------------------------------------------------------------
# TestPublishEvent  (POST /channels/{channel}/events)
# -----------------------------------------------------------------------------

class TestPublishEvent:

    def test_publish_returns_200(self):
        ch = _unique()
        _create(ch)
        assert _publish(ch, "hello").status_code == 200

    def test_publish_response_contains_id_field(self):
        ch = _unique()
        _create(ch)
        body = _publish(ch, "hello").json()
        assert "id" in body

    def test_publish_id_is_string_type(self):
        ch = _unique()
        _create(ch)
        body = _publish(ch, "hello").json()
        assert isinstance(body["id"], str)

    def test_publish_id_is_non_empty(self):
        ch = _unique()
        _create(ch)
        body = _publish(ch, "hello").json()
        assert body["id"] != ""

    def test_first_auto_assigned_id_is_1(self):
        ch = _unique()
        _create(ch)
        assert _publish(ch, "first").json()["id"] == "1"

    def test_auto_assigned_ids_increment_sequentially(self):
        ch = _unique()
        _create(ch)
        ids = [_publish(ch, f"e{i}").json()["id"] for i in range(4)]
        assert ids == ["1", "2", "3", "4"]

    def test_auto_assigned_ids_are_independent_per_channel(self):
        ch1, ch2 = _unique(), _unique()
        _create(ch1)
        _create(ch2)
        assert _publish(ch1, "a").json()["id"] == "1"
        assert _publish(ch2, "b").json()["id"] == "1"

    def test_missing_data_field_returns_400(self):
        ch = _unique()
        _create(ch)
        resp = requests.post(_url(f"/channels/{ch}/events"), json={}, timeout=5)
        assert resp.status_code == 400

    def test_empty_data_field_returns_400(self):
        ch = _unique()
        _create(ch)
        resp = requests.post(_url(f"/channels/{ch}/events"),
                             json={"data": ""}, timeout=5)
        assert resp.status_code == 400

    def test_publish_to_nonexistent_channel_returns_404(self):
        assert _publish("channel-that-does-not-exist-xyz", "x").status_code == 404

    def test_optional_event_field_accepted(self):
        ch = _unique()
        _create(ch)
        assert _publish(ch, "data", event="update").status_code == 200


# -----------------------------------------------------------------------------
# TestAccessControl
# -----------------------------------------------------------------------------

class TestAccessControl:

    def test_publish_no_token_required_when_none_set(self):
        ch = _unique()
        _create(ch)
        assert _publish(ch, "data").status_code == 200

    def test_publish_correct_token_returns_200(self):
        ch = _unique()
        _create(ch, publish_token="p-secret")
        assert _publish(ch, "data", token="p-secret").status_code == 200

    def test_publish_wrong_token_returns_401(self):
        ch = _unique()
        _create(ch, publish_token="p-secret")
        assert _publish(ch, "data", token="wrong").status_code == 401

    def test_publish_missing_token_returns_401(self):
        ch = _unique()
        _create(ch, publish_token="p-secret")
        assert _publish(ch, "data").status_code == 401

    def test_subscribe_no_token_required_when_none_set(self):
        ch = _unique()
        _create(ch)
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.status_code == 200
        resp.close()

    def test_subscribe_correct_token_returns_200(self):
        ch = _unique()
        _create(ch, subscribe_token="s-secret")
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream",
                                     "Authorization": "Bearer s-secret"},
                            stream=True, timeout=3)
        assert resp.status_code == 200
        resp.close()

    def test_subscribe_wrong_token_returns_401(self):
        ch = _unique()
        _create(ch, subscribe_token="s-secret")
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream",
                                     "Authorization": "Bearer wrong"},
                            stream=True, timeout=3)
        assert resp.status_code == 401

    def test_subscribe_missing_token_returns_401(self):
        ch = _unique()
        _create(ch, subscribe_token="s-secret")
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.status_code == 401

    def test_publish_token_does_not_require_subscribe_auth(self):
        """Channel with only publish_token allows unauthenticated subscribe."""
        ch = _unique()
        _create(ch, publish_token="p-only")
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.status_code == 200
        resp.close()

    def test_subscribe_token_does_not_require_publish_auth(self):
        """Channel with only subscribe_token allows unauthenticated publish."""
        ch = _unique()
        _create(ch, subscribe_token="s-only")
        assert _publish(ch, "data").status_code == 200


# -----------------------------------------------------------------------------
# TestSSEResponseFormat
# Verifies: response headers, wire format, 404 on missing channel
# -----------------------------------------------------------------------------

class TestSSEResponseFormat:

    def test_content_type_is_text_event_stream(self):
        ch = _unique()
        _create(ch)
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert "text/event-stream" in resp.headers.get("Content-Type", "")
        resp.close()

    def test_cache_control_header_is_no_cache(self):
        ch = _unique()
        _create(ch)
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.headers.get("Cache-Control") == "no-cache"
        resp.close()

    def test_x_accel_buffering_header_is_no(self):
        ch = _unique()
        _create(ch)
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.headers.get("X-Accel-Buffering") == "no"
        resp.close()

    def test_subscribe_to_nonexistent_channel_returns_404(self):
        resp = requests.get(_url("/channels/nonexistent-xyz-never/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=3)
        assert resp.status_code == 404

    def test_live_event_data_field_matches_published_data(self):
        ch = _unique()
        _create(ch)
        received: List[dict] = []

        def sub():
            received.extend(_collect_sse(ch, count=1, timeout=5.0))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.35)
        _publish(ch, "payload-abc")
        t.join(timeout=6.0)

        assert len(received) >= 1
        assert received[0].get("data") == "payload-abc"

    def test_live_event_id_field_is_present_in_wire_format(self):
        ch = _unique()
        _create(ch)
        received: List[dict] = []

        def sub():
            received.extend(_collect_sse(ch, count=1, timeout=5.0))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.35)
        _publish(ch, "id-check")
        t.join(timeout=6.0)

        assert len(received) >= 1
        assert "id" in received[0]

    def test_event_type_field_present_when_published_with_event(self):
        ch = _unique()
        _create(ch)
        received: List[dict] = []

        def sub():
            received.extend(_collect_sse(ch, count=1, timeout=5.0))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.35)
        _publish(ch, "typed-payload", event="status-update")
        t.join(timeout=6.0)

        assert len(received) >= 1
        assert received[0].get("event") == "status-update"

    def test_live_event_id_matches_server_assigned_id(self):
        ch = _unique()
        _create(ch)
        received: List[dict] = []

        def sub():
            received.extend(_collect_sse(ch, count=1, timeout=5.0))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.35)
        pub_resp = _publish(ch, "id-match-check")
        assigned_id = pub_resp.json()["id"]
        t.join(timeout=6.0)

        assert len(received) >= 1
        assert received[0].get("id") == assigned_id

    def test_event_field_absent_in_sse_when_not_published_with_event(self):
        """Wire format: event: line must be omitted when no event field was published."""
        ch = _unique()
        _create(ch)
        received: List[dict] = []

        def sub():
            received.extend(_collect_sse(ch, count=1, timeout=5.0))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.35)
        _publish(ch, "no-event-type")  # no event field
        t.join(timeout=6.0)

        assert len(received) >= 1
        assert "event" not in received[0]


# -----------------------------------------------------------------------------
# TestFanOut
# Verifies: broadcast to all concurrent subscribers
# -----------------------------------------------------------------------------

class TestFanOut:

    def test_two_subscribers_both_receive_live_event(self):
        ch = _unique()
        _create(ch)
        results: List[List[dict]] = [[], []]

        def make_sub(idx: int):
            def sub():
                results[idx].extend(_collect_sse(ch, count=1, timeout=5.0))
            return sub

        threads = [threading.Thread(target=make_sub(i), daemon=True) for i in range(2)]
        for t in threads:
            t.start()
        time.sleep(0.4)
        _publish(ch, "broadcast-payload")
        for t in threads:
            t.join(timeout=6.0)

        assert len(results[0]) >= 1, "Subscriber 0 received nothing"
        assert len(results[1]) >= 1, "Subscriber 1 received nothing"
        assert results[0][0].get("data") == "broadcast-payload"
        assert results[1][0].get("data") == "broadcast-payload"

    def test_subscriber_on_different_channel_does_not_receive_event(self):
        ch1, ch2 = _unique(), _unique()
        _create(ch1)
        _create(ch2)
        received_ch2: List[dict] = []

        def sub_ch2():
            received_ch2.extend(_collect_sse(ch2, count=1, timeout=1.5))

        t = threading.Thread(target=sub_ch2, daemon=True)
        t.start()
        time.sleep(0.3)
        _publish(ch1, "only-for-ch1")
        t.join(timeout=2.5)

        # ch2 subscriber should not have received ch1's event
        assert all(e.get("data") != "only-for-ch1" for e in received_ch2)

    def test_server_still_functional_after_subscriber_disconnects(self):
        """Verifies no resource leak blocks subsequent operations."""
        ch = _unique()
        _create(ch)

        # Connect and immediately disconnect
        resp = requests.get(_url(f"/channels/{ch}/events"),
                            headers={"Accept": "text/event-stream"},
                            stream=True, timeout=2)
        resp.close()

        time.sleep(0.3)

        # Server must still handle new requests normally
        assert _publish(ch, "after-disconnect").status_code == 200


# -----------------------------------------------------------------------------
# TestHistoryReplay
# Verifies: ring buffer, Last-Event-ID resumption, default history size
# -----------------------------------------------------------------------------

class TestHistoryReplay:

    def test_full_history_replayed_without_last_event_id(self):
        ch = _unique()
        _create(ch, history_size=10)
        _publish(ch, "hist-a")
        _publish(ch, "hist-b")

        events = _collect_sse(ch, count=2, timeout=5.0)
        data = [e.get("data") for e in events]
        assert "hist-a" in data
        assert "hist-b" in data

    def test_last_event_id_replays_only_newer_events(self):
        ch = _unique()
        _create(ch, history_size=10)
        _publish(ch, "e1")  # id=1
        _publish(ch, "e2")  # id=2
        _publish(ch, "e3")  # id=3

        # Resume from id=2; only e3 (id=3) should be replayed
        events = _collect_sse(ch, count=1, last_event_id="2", timeout=5.0)
        data = [e.get("data") for e in events]
        assert "e3" in data
        assert "e1" not in data
        assert "e2" not in data

    def test_last_event_id_zero_replays_all_history(self):
        ch = _unique()
        _create(ch, history_size=10)
        _publish(ch, "first")
        _publish(ch, "second")

        events = _collect_sse(ch, count=2, last_event_id="0", timeout=5.0)
        data = [e.get("data") for e in events]
        assert "first" in data
        assert "second" in data

    def test_unparseable_last_event_id_replays_full_history(self):
        ch = _unique()
        _create(ch, history_size=10)
        _publish(ch, "alpha")
        _publish(ch, "beta")

        events = _collect_sse(ch, count=2, last_event_id="not-a-number", timeout=5.0)
        data = [e.get("data") for e in events]
        assert "alpha" in data
        assert "beta" in data

    def test_ring_buffer_evicts_oldest_when_full(self):
        ch = _unique()
        _create(ch, history_size=2)
        _publish(ch, "will-be-evicted")   # id=1
        _publish(ch, "kept-1")            # id=2
        _publish(ch, "kept-2")            # id=3; evicts id=1

        events = _collect_sse(ch, count=2, timeout=5.0)
        data = [e.get("data") for e in events]
        assert "will-be-evicted" not in data
        assert "kept-1" in data
        assert "kept-2" in data

    def test_history_size_zero_no_events_replayed_on_connect(self):
        ch = _unique()
        _create(ch, history_size=0)
        _publish(ch, "unreplayable")

        # Connect after publish; then publish a live event and wait for it
        received: List[dict] = []

        def sub():
            received.extend(_collect_sse(ch, count=1, timeout=3.5))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.35)
        _publish(ch, "live-only-event")
        t.join(timeout=5.0)

        # First (and only) received event should be the live one
        assert len(received) >= 1
        assert received[0].get("data") == "live-only-event"

    def test_history_events_precede_live_events(self):
        ch = _unique()
        _create(ch, history_size=10)
        _publish(ch, "before-connect")

        all_events: List[dict] = []

        def sub():
            # Collect exactly 2 events: 1 from history, 1 live
            all_events.extend(_collect_sse(ch, count=2, timeout=6.0))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.5)  # allow history replay to arrive first
        _publish(ch, "after-connect")
        t.join(timeout=7.0)

        assert len(all_events) >= 2
        assert all_events[0].get("data") == "before-connect"
        assert all_events[1].get("data") == "after-connect"

    def test_omitting_history_size_uses_server_default(self):
        """Server started with --default-history-size=100; 5 events should all replay."""
        ch = _unique()
        _create(ch)  # no history_size -> defaults to 100
        for i in range(5):
            _publish(ch, f"item-{i}")

        events = _collect_sse(ch, count=5, timeout=5.0)
        assert len(events) == 5

    def test_last_event_id_at_end_of_history_replays_nothing(self):
        ch = _unique()
        _create(ch, history_size=10)
        _publish(ch, "only-event")  # id=1

        # Resume from id=1; nothing should be replayed (no id > 1 in history)
        # Then publish a live event and expect only that
        received: List[dict] = []

        def sub():
            received.extend(_collect_sse(ch, count=1, last_event_id="1", timeout=3.5))

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        time.sleep(0.35)
        _publish(ch, "new-live")
        t.join(timeout=5.0)

        assert len(received) >= 1
        assert received[0].get("data") == "new-live"
    
    def test_event_field_preserved_in_history_replay(self):
        """Events published with an event field must have that field intact on replay."""
        ch = _unique()
        _create(ch, history_size=10)
        _publish(ch, "payload", event="order-placed")

        events = _collect_sse(ch, count=1, timeout=5.0)
        assert len(events) >= 1
        assert events[0].get("event") == "order-placed"


# -----------------------------------------------------------------------------
# TestKeepalive
# Verifies: :keepalive comment sent within 20 seconds on idle stream
# -----------------------------------------------------------------------------

class TestKeepalive:

    def test_keepalive_comment_received_within_20_seconds(self):
        ch = _unique()
        _create(ch)

        got_keepalive = threading.Event()

        def sub():
            lines = _subscribe_raw_lines(ch, timeout=22.0)
            if any(ln.startswith(":keepalive") for ln in lines):
                got_keepalive.set()

        t = threading.Thread(target=sub, daemon=True)
        t.start()
        assert got_keepalive.wait(timeout=20.0), \
            "No :keepalive comment received within 20 seconds on an idle stream"
        t.join(timeout=1.0)