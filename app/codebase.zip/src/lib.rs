//! `text_diff` — a small, dependency-free text diffing library.
//!
//! The crate exposes line-level and word-level diffs computed from a Longest
//! Common Subsequence (LCS) edit script, plus convenience renderers for the
//! unified-diff and side-by-side formats and a similarity ratio.
//!
//! All public functions operate on UTF-8 strings (or any [`std::io::BufRead`]
//! source for [`diff_reader`]) and use only the standard library.

use std::io::BufRead;

/// A single entry in a line-level edit script.
///
/// Line numbers are 1-based and refer to the position of the line in the
/// corresponding (old or new) input. The `content` string is the line body
/// with the trailing `\n` already stripped.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Change {
    /// A line that is unchanged between the old and new inputs. Carries both
    /// the old and new line numbers because they may differ.
    Equal {
        old_line: usize,
        new_line: usize,
        content: String,
    },
    /// A line present only in the old input.
    Delete {
        old_line: usize,
        content: String,
    },
    /// A line present only in the new input.
    Insert {
        new_line: usize,
        content: String,
    },
}

/// A single entry in a word-level edit script produced by [`word_diff`].
///
/// Tokens are either maximal whitespace runs or maximal non-whitespace runs,
/// preserved verbatim so that concatenating the tokens of either side
/// reconstructs the original line exactly.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WordChange {
    Equal(String),
    Delete(String),
    Insert(String),
}

// Internal index-only edit operation. Kept separate from `Change` so the
// LCS backtracking step can work on bare indices and content is attached
// later by `build_changes` / `word_diff`.
enum EditOp {
    Equal(usize, usize),
    Delete(usize),
    Insert(usize),
}

// Split on '\n'. The empty string yields zero lines (not one), and a
// trailing newline does not produce a phantom empty final line — both
// conventions match the prompt and `read_lines` below.
fn split_lines(s: &str) -> Vec<&str> {
    if s.is_empty() {
        return Vec::new();
    }
    let mut v: Vec<&str> = s.split('\n').collect();
    if v.last() == Some(&"") {
        v.pop();
    }
    v
}

// Classic O(N*M) LCS dynamic programming table. dp[i][j] is the LCS length
// of a[..i] and b[..j]. Used by `compute_edit_script` for backtracking.
fn lcs_table<T: Eq>(a: &[T], b: &[T]) -> Vec<Vec<usize>> {
    let n = a.len();
    let m = b.len();
    let mut dp = vec![vec![0usize; m + 1]; n + 1];
    for i in 0..n {
        for j in 0..m {
            if a[i] == b[j] {
                dp[i + 1][j + 1] = dp[i][j] + 1;
            } else {
                dp[i + 1][j + 1] = dp[i + 1][j].max(dp[i][j + 1]);
            }
        }
    }
    dp
}

// Walk the LCS table from the bottom-right corner back to the origin,
// emitting Equal / Delete / Insert ops. The total number of Delete + Insert
// ops is N + M - 2*LCS, which is provably the minimum possible edit script.
fn compute_edit_script<T: Eq>(a: &[T], b: &[T]) -> Vec<EditOp> {
    let dp = lcs_table(a, b);
    let mut ops = Vec::new();
    let mut i = a.len();
    let mut j = b.len();
    while i > 0 || j > 0 {
        if i > 0 && j > 0 && a[i - 1] == b[j - 1] {
            ops.push(EditOp::Equal(i - 1, j - 1));
            i -= 1;
            j -= 1;
        } else if j > 0 && (i == 0 || dp[i][j - 1] >= dp[i - 1][j]) {
            // Prefer Insert when it doesn't shorten the LCS — this also
            // gives a stable ordering of "deletes before inserts" when we
            // reverse the ops below into natural top-to-bottom order.
            ops.push(EditOp::Insert(j - 1));
            j -= 1;
        } else {
            ops.push(EditOp::Delete(i - 1));
            i -= 1;
        }
    }
    ops.reverse();
    ops
}

fn build_changes(old: &[&str], new: &[&str]) -> Vec<Change> {
    let ops = compute_edit_script(old, new);
    ops.into_iter()
        .map(|op| match op {
            EditOp::Equal(i, j) => Change::Equal {
                old_line: i + 1,
                new_line: j + 1,
                content: old[i].to_string(),
            },
            EditOp::Delete(i) => Change::Delete {
                old_line: i + 1,
                content: old[i].to_string(),
            },
            EditOp::Insert(j) => Change::Insert {
                new_line: j + 1,
                content: new[j].to_string(),
            },
        })
        .collect()
}

/// Compute a minimal line-level edit script between two strings.
///
/// The result is a `Vec<Change>` in natural top-to-bottom reading order
/// whose `Delete` + `Insert` count is the minimum over all edit scripts
/// transforming `old` into `new`. Lines are split on `\n`; a trailing
/// newline does not introduce an empty final line and the empty string
/// produces zero lines.
pub fn diff(old: &str, new: &str) -> Vec<Change> {
    let a = split_lines(old);
    let b = split_lines(new);
    build_changes(&a, &b)
}

/// Render a unified-diff string with `context` lines of surrounding
/// context around each hunk.
///
/// The header for each hunk has the exact form
/// `@@ -<old_start>,<old_len> +<new_start>,<new_len> @@\n`. When a side of
/// a hunk has zero lines, its start number is the line number of the last
/// line of that side preceding the hunk (or `0` if the hunk begins before
/// any line of that side). Context lines are prefixed with a space,
/// deletions with `-`, insertions with `+`, and every rendered line is
/// terminated with `\n`. Identical inputs yield an empty string.
pub fn unified_diff(old: &str, new: &str, context: usize) -> String {
    if old == new {
        return String::new();
    }
    let script = diff(old, new);

    // Indices of the non-Equal entries — these are the "anchor" points
    // around which we expand context windows.
    let diff_indices: Vec<usize> = script
        .iter()
        .enumerate()
        .filter_map(|(i, c)| {
            if matches!(c, Change::Equal { .. }) {
                None
            } else {
                Some(i)
            }
        })
        .collect();

    if diff_indices.is_empty() {
        return String::new();
    }

    // Merge adjacent change anchors whose post-expansion context windows
    // would touch or overlap. Two anchors at script positions `a` and `b`
    // are separated by `b - a - 1` Equal entries; after expanding by
    // `context` on each side they remain disjoint only if those Equal
    // entries number strictly more than `2 * context`, i.e.
    // `b - a > 2 * context + 1`. The complementary `<=` is the merge.
    let mut groups: Vec<(usize, usize)> = Vec::new();
    let mut group_start = diff_indices[0];
    let mut group_end = diff_indices[0];
    for &idx in &diff_indices[1..] {
        if idx - group_end <= 2 * context + 1 {
            group_end = idx;
        } else {
            groups.push((group_start, group_end));
            group_start = idx;
            group_end = idx;
        }
    }
    groups.push((group_start, group_end));

    // Expand each anchor group by `context` lines on either side, clamped
    // to the script bounds, to obtain the actual hunk slice [hs, he).
    let hunks: Vec<(usize, usize)> = groups
        .into_iter()
        .map(|(s, e)| {
            let hs = s.saturating_sub(context);
            let he = (e + context + 1).min(script.len());
            (hs, he)
        })
        .collect();

    let mut out = String::new();
    let mut old_consumed = 0usize;
    let mut new_consumed = 0usize;
    let mut cursor = 0usize;

    for (hs, he) in hunks {
        while cursor < hs {
            match &script[cursor] {
                Change::Equal { .. } => {
                    old_consumed += 1;
                    new_consumed += 1;
                }
                Change::Delete { .. } => {
                    old_consumed += 1;
                }
                Change::Insert { .. } => {
                    new_consumed += 1;
                }
            }
            cursor += 1;
        }

        let mut old_len = 0usize;
        let mut new_len = 0usize;
        for c in &script[hs..he] {
            match c {
                Change::Equal { .. } => {
                    old_len += 1;
                    new_len += 1;
                }
                Change::Delete { .. } => {
                    old_len += 1;
                }
                Change::Insert { .. } => {
                    new_len += 1;
                }
            }
        }
        // When a side contributes zero lines to the hunk, the unified-diff
        // convention is to report the line number of the last preceding
        // line on that side (0 if none) rather than `old_consumed + 1`.
        let old_start = if old_len == 0 {
            old_consumed
        } else {
            old_consumed + 1
        };
        let new_start = if new_len == 0 {
            new_consumed
        } else {
            new_consumed + 1
        };

        out.push_str(&format!(
            "@@ -{},{} +{},{} @@\n",
            old_start, old_len, new_start, new_len
        ));

        for c in &script[hs..he] {
            match c {
                Change::Equal { content, .. } => {
                    out.push(' ');
                    out.push_str(content);
                    out.push('\n');
                }
                Change::Delete { content, .. } => {
                    out.push('-');
                    out.push_str(content);
                    out.push('\n');
                }
                Change::Insert { content, .. } => {
                    out.push('+');
                    out.push_str(content);
                    out.push('\n');
                }
            }
        }
    }

    out
}

// Width is measured in Unicode scalar values (`char`s), not bytes, so a
// 4-char string like "café" occupies 4 columns regardless of UTF-8 byte
// length. Strings shorter than `width` are right-padded with ASCII spaces;
// longer strings are truncated to exactly `width` chars.
fn pad_or_truncate(s: &str, width: usize) -> String {
    let chars: Vec<char> = s.chars().collect();
    let len = chars.len();
    if len >= width {
        chars.into_iter().take(width).collect::<String>()
    } else {
        let mut result: String = chars.into_iter().collect();
        for _ in 0..(width - len) {
            result.push(' ');
        }
        result
    }
}

fn push_row(out: &mut String, left: &str, right: &str, marker: char, width: usize) {
    out.push_str(&pad_or_truncate(left, width));
    out.push_str(" | ");
    out.push(marker);
    out.push_str(" | ");
    out.push_str(&pad_or_truncate(right, width));
    out.push('\n');
}

/// Render the full edit script in a two-column layout.
///
/// Each row has the shape `<left> | <marker> | <right>\n`, where the left
/// and right columns are padded/truncated to exactly `width` Unicode
/// scalar values. The marker is `' '` for an unchanged line, `'<'` for a
/// pure deletion, `'>'` for a pure insertion, and `'|'` for a replacement
/// (a `Delete` immediately followed by an `Insert` in the script). Unlike
/// [`unified_diff`] this renders the entire script without a context
/// radius, so unchanged lines are also included.
pub fn side_by_side(old: &str, new: &str, width: usize) -> String {
    let script = diff(old, new);
    let mut out = String::new();
    let mut i = 0;
    while i < script.len() {
        match &script[i] {
            Change::Equal { content, .. } => {
                push_row(&mut out, content, content, ' ', width);
                i += 1;
            }
            Change::Delete { content: oc, .. } => {
                if i + 1 < script.len() {
                    if let Change::Insert { content: nc, .. } = &script[i + 1] {
                        push_row(&mut out, oc, nc, '|', width);
                        i += 2;
                        continue;
                    }
                }
                push_row(&mut out, oc, "", '<', width);
                i += 1;
            }
            Change::Insert { content, .. } => {
                push_row(&mut out, "", content, '>', width);
                i += 1;
            }
        }
    }
    out
}

// Split a string into alternating runs of whitespace and non-whitespace
// characters. Concatenating the resulting tokens reproduces the input
// byte-for-byte, which is what `word_diff`'s reconstruction guarantee
// relies on.
fn tokenize_words(s: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    let mut in_ws = false;
    for ch in s.chars() {
        let is_ws = ch.is_whitespace();
        if current.is_empty() {
            current.push(ch);
            in_ws = is_ws;
        } else if is_ws == in_ws {
            current.push(ch);
        } else {
            tokens.push(std::mem::take(&mut current));
            current.push(ch);
            in_ws = is_ws;
        }
    }
    if !current.is_empty() {
        tokens.push(current);
    }
    tokens
}

/// Compute a minimal word-level edit script between two single lines.
///
/// Both inputs are tokenised into maximal whitespace and non-whitespace
/// runs (see [`WordChange`]) and the same LCS algorithm used by [`diff`]
/// is applied at the token level. Concatenating all `Equal`/`Delete`
/// tokens reproduces `old_line`; concatenating all `Equal`/`Insert`
/// tokens reproduces `new_line`.
pub fn word_diff(old_line: &str, new_line: &str) -> Vec<WordChange> {
    let a = tokenize_words(old_line);
    let b = tokenize_words(new_line);
    let ops = compute_edit_script(&a, &b);
    ops.into_iter()
        .map(|op| match op {
            EditOp::Equal(i, _) => WordChange::Equal(a[i].clone()),
            EditOp::Delete(i) => WordChange::Delete(a[i].clone()),
            EditOp::Insert(j) => WordChange::Insert(b[j].clone()),
        })
        .collect()
}

/// A SequenceMatcher-style similarity ratio in `[0.0, 1.0]`.
///
/// Defined as `2 * M / T` where `M` is the LCS length (in lines) and `T`
/// is the total line count of both inputs. Two empty inputs are defined
/// to be perfectly similar (`1.0`); an empty input paired with a
/// non-empty one yields `0.0`.
pub fn similarity(old: &str, new: &str) -> f64 {
    let a = split_lines(old);
    let b = split_lines(new);
    let t = a.len() + b.len();
    if t == 0 {
        return 1.0;
    }
    let dp = lcs_table(&a, &b);
    let m = dp[a.len()][b.len()];
    2.0 * (m as f64) / (t as f64)
}

// Read all lines from a `BufRead`, stripping a single trailing '\n' from
// each. Mirrors the convention used by `split_lines` so an in-memory diff
// and a streamed diff of the same content produce identical results. Any
// I/O error is propagated unchanged.
fn read_lines(reader: &mut dyn BufRead) -> std::io::Result<Vec<String>> {
    let mut lines = Vec::new();
    loop {
        let mut buf = String::new();
        let n = reader.read_line(&mut buf)?;
        if n == 0 {
            break;
        }
        if buf.ends_with('\n') {
            buf.pop();
        }
        lines.push(buf);
    }
    Ok(lines)
}

/// Streamed counterpart to [`diff`] that reads its inputs from any
/// [`std::io::BufRead`] sources.
///
/// Both readers are drained line by line into in-memory buffers (the LCS
/// step needs random access on both sides, so true streaming isn't
/// possible) and then fed through the same edit-script builder. Any
/// `std::io::Error` produced while reading is propagated to the caller.
pub fn diff_reader(
    old: &mut dyn BufRead,
    new: &mut dyn BufRead,
) -> std::io::Result<Vec<Change>> {
    let old_lines = read_lines(old)?;
    let new_lines = read_lines(new)?;
    let a: Vec<&str> = old_lines.iter().map(|s| s.as_str()).collect();
    let b: Vec<&str> = new_lines.iter().map(|s| s.as_str()).collect();
    Ok(build_changes(&a, &b))
}
