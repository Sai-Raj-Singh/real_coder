module sse-broker

go 1.22