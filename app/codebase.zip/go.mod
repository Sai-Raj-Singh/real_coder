module fluenthttp

go 1.21
